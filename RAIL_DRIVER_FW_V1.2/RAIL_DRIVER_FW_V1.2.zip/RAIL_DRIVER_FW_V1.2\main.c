/*********************************************************************
*
* DRIVER RAIL V 1.2
*
* MAIN.C
*
*********************************************************************
* Processor: PIC18F4585
* Frequency: 32 Mhz
* Compiler: C18
*********************************************************************/
#include "main.h"
//////////////////////////////////////////////////////////////////////////////
// EEPROM READ / WRITE FUNCTION 
//////////////////////////////////////////////////////////////////////////////
/**********************************************************
	This function reads a byte at given addresse in EEPROM.
	IN:		address
	OUT:	data
	Return Value: ERROR, SUCCESS
**********************************************************/
unsigned char ReadEEPROM(unsigned int adr, unsigned char *data){

	if(adr > 0x3FF){
		return(ERROR);
	}
	else{
		EEADR = adr&0xFF;
		EEADRH = (adr>>8) & 0x3;
		EECON1bits.EEPGD = 0;	// Point to data memory
		EECON1bits.CFGS = 0;	// Access EEPROM
		EECON1bits.RD = 1;		// Read data
		*data = EEDATA;			// Load data
		return(SUCCESS);
	}
} // end of readEEPROM()

/****************************************************************************
*
* Function ResetEEPROM
*
****************************************************************************/
void ResetEEPROM(){

	 unsigned char 	Value;
	 unsigned short adr;
	 unsigned char  checkMagicNumberCounter;

	// Init EEPROM after flashing the board
	adr=(unsigned short)MAGICNUMBER_ADDRESS;
	for (checkMagicNumberCounter=0;checkMagicNumberCounter<MAGICNUMBERSIZE;checkMagicNumberCounter++) {
		WriteEEPROM(adr++,checkMagicNumberCounter);
	}
	// Set ANA mode
	adr=(unsigned short)MODE_ADDRESS;
	Value=ANAValue;
	WriteEEPROM(adr,Value);

	// No automation
	adr=(unsigned short)LASTAUTOMATION_ADDRESS;
	Value=0;
	WriteEEPROM(adr,Value);

	gl_mutex=1;gl_mode = ANAValue;gl_lastAutomation=0;gl_mutex=0;

	// GPIO IN
	for(adr=(unsigned short)GPIO0DIR_ADDRESS;adr<=(unsigned short)GPIO0DIR_ADDRESS+3;adr++)WriteEEPROM(adr,1);
	
	// Init
	initSignal();

	// Calibration
	calibration();
}

/****************************************************************************
*
* Function ReadEEPROMConfig
*
****************************************************************************/
void ReadEEPROMConfig(void) {

	 unsigned char 	Value;
	 unsigned short adr;
	 unsigned char  automationCounter;
	 unsigned char  automationDataCounter;
	 unsigned char  checkMagicNumberCounter;

	// Read MAGIC NUMBER
	adr=(unsigned char)MAGICNUMBER_ADDRESS;
	for (checkMagicNumberCounter=0;checkMagicNumberCounter<MAGICNUMBERSIZE;checkMagicNumberCounter++) {
		ReadEEPROM(adr++,&Value);
		if (Value!=checkMagicNumberCounter) {
			
			ResetEEPROM();
			return;
		}
	}	

	// Read in EEPROM MODE 
	adr=(unsigned short)MODE_ADDRESS;
	ReadEEPROM(adr,&Value);
	gl_mutex=1;gl_mode=Value;gl_mutex=0;

	// Read in GPIO dir
	adr=(unsigned short)GPIO0DIR_ADDRESS;
	ReadEEPROM(adr++,&Value);
	TRISDbits.RD1=Value;
	ReadEEPROM(adr++,&Value);
	TRISDbits.RD2=Value;
	ReadEEPROM(adr++,&Value);
	TRISDbits.RD3=Value;
	ReadEEPROM(adr,&Value);
	TRISCbits.RC4=Value;
	
	// Read in EEPROM last automation
	adr=(unsigned short)LASTAUTOMATION_ADDRESS;
	ReadEEPROM(adr,&Value);
	gl_lastAutomation=Value;

	// Read in EEPROM Automation
	adr=(unsigned short)AUTOMATION_ADDRESS;

	for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {	
		for(automationDataCounter=0;automationDataCounter<AUTOMATIONSIZE;automationDataCounter++) {
			ReadEEPROM(adr++,&Value);	
			gl_automation[automationCounter][automationDataCounter]=Value;	
		}
	}
}

/**********************************************************
	This function informs on if write to EEPROM is completed.
	IN:		None
	OUT:	None
	Return Value: IN_PROGRESS, SUCCESS
**********************************************************/
unsigned char WriteCompletedEEPROM(void) {

	if(PIR2bits.EEIF){
		PIR2bits.EEIF=0;		// Clear write complete flag
		EECON1bits.WREN = 0;	// Disable write
		return(SUCCESS);		// Write to EEPROM completed
	}
	else {
		return(ERROR);			// Write to EEPROM not completed
	}
}

/**********************************************************
	This function informs on if it is possible to write in EEPROM.
	IN:		None
	OUT:	None
	Return Value: ERROR, SUCCESS
**********************************************************/
unsigned char WriteRdyEEPROM(void){

	if(!EECON1bits.WR) {
		return(SUCCESS);	// New Write Enabled
	}
	else {
		return(ERROR);		// new Write Disabled
	}
}

/**********************************************************
	This function writes a byte at given addresse in EEPROM.
	IN:		addresse, data
	Return Value: ERROR, SUCCESS
**********************************************************/
unsigned char WriteEEPROM(unsigned short adr, unsigned char data){
	if(adr > 0x3FF){
		return(ERROR);
	}
	else{

		// Wait eeprom ready to be written
		while (WriteRdyEEPROM()==(unsigned char) ERROR);

		EEADR = adr&0xFF;			// Address of the data in EEPROM
		EEADRH = (adr>>8) & 0x3;	// Address of the data in EEPROM
		EEDATA = data;				// Data to write in EEPROM
		EECON1bits.EEPGD = 0;		// Point to data memory
		EECON1bits.CFGS = 0;		// Access EEPROM
		EECON1bits.WREN = 1;		// Enable write
		INTCONbits.GIE	= 0;		// Disable Interrupt
		EECON2 = 0x55;
		EECON2 = 0x0AA;
		EECON1bits.WR = 1;			// Begin write

		// Wait data written
		while (WriteCompletedEEPROM()==(unsigned char) IN_PROGRESS);
		while (WriteRdyEEPROM()==(unsigned char) ERROR);

		INTCONbits.GIE		= 1;	// Enable Interrupt
	
		return(SUCCESS);
	}
} // end of WriteEEPROM()

//////////////////////////////////////////////////////////////////////////////
// PARSER AND REQUEST MANAGEMENT
//////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// isAdigit
/////////////////////////////////////////////////////////////////////////////
unsigned char isAdigit(unsigned char car) {
	if (car >='0' && car <= '9') return TRUE;
	else return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// isAhexaDigit
/////////////////////////////////////////////////////////////////////////////
unsigned char isAhexaDigit(unsigned char car) {
	if ((car >='a' && car <= 'f')  || (car >='A' && car <= 'F')) return TRUE;
	else return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// toUpperCase
/////////////////////////////////////////////////////////////////////////////
unsigned char toUpperCase(unsigned char car) {

    unsigned char returnValue;

	if (car >='a' && car <= 'z') returnValue=car - 0x20;
	else returnValue=car;

	return(returnValue);
}
/////////////////////////////////////////////////////////////////////////////
// strtol_with_atoi for positive number
/////////////////////////////////////////////////////////////////////////////
unsigned short strtol_with_atoi(const char* nptr, short base) {

	unsigned short result=0;
	unsigned char getData=FALSE;

	// Check sign
	if (*nptr == '-') {
		errno = ERANGE;
		return result;
	}
	else if (*nptr == '+') {
		nptr++;
	}

	// Check base 0x for hexad�cimal, 0 for octal
	if (base == 0) {
		if (*nptr == '0') {
			nptr++;
			getData=TRUE;
			if (*nptr == 'x' || *nptr == 'X') {
				nptr++;
				base = 16;
				getData=FALSE;
			}
		}
		else {
			base = 10;
		}
	}

	// atoi()
	result = 0;
	while (*nptr != '\0') {
		int digit;
		if (isAdigit(*nptr)) {
			digit = *nptr - '0';
			getData=TRUE;
		}
		else if (base == 16 && isAhexaDigit(*nptr)) {
			digit = toUpperCase(*nptr) - 'A' + 10;
			getData=TRUE;
		}
		else {
			// end converstion
			break;
		}

		// Check value for base
		if (digit >= base) {
			// Fin de la conversion
			errno = ERANGE;
			return result;
		}

		result = result * base + digit;
		nptr++;
	}
	if (getData==FALSE) errno = EINVAL;
	return result;
}

/////////////////////////////////////////////////////////////////////////////
// traceError 
/////////////////////////////////////////////////////////////////////////////
void traceError() {

	static unsigned char message[MAXMESSAGESIZE];

	switch (gl_parserErrorCode) {	
		case UNKNOWN_TOKEN				:		sprintf(message,"Unknown token");break;
		case NUMBER_MISSING				:		sprintf(message,"Number missing");break;
		case INCOMPLETE_REQUEST			:		sprintf(message,"Incomplete request");break;
		case BAD_NUMBER					:		sprintf(message,"Bad number");break;
		case MODE_MISSING				:		sprintf(message,"Mode is missing");break;
		case BAD_GPIO_NUMBER			:		sprintf(message,"Bad GPIO number");break;
		case BAD_TIMER_NUMBER			:		sprintf(message,"Bad TIMER number");break;
		case BAD_TIMER_VALUE			:		sprintf(message,"Bad TIMER value");break;
		case BAD_LPO_NUMBER				:		sprintf(message,"Bad LPO number");break;
		case BAD_GPIO_DIR				:		sprintf(message,"Bad GPIO direction");break;
		case CANT_SET_GPIO_IN_INPUT_MODE:		sprintf(message,"Can't set GPIO, need to be set as output");break;
		case BAD_GPIO_LEVEL				:		sprintf(message,"Bad GPIO level");break;
		case BAD_LPO_LEVEL				:		sprintf(message,"Bad Low Power Output level");break;
		case BAD_TRACK_SPEED			:		sprintf(message,"Bad track speed");break;
		case BAD_TRACK_DIR				:		sprintf(message,"Bad track direction");break;
		case BAD_TRACK_NUMBER			:		sprintf(message,"Bad track number");break;
		case BAD_MODE					:		sprintf(message,"Bad mode");break;
		case WRONG_BOARD_NUMBER			:		sprintf(message,"Wrong board number");break;
		case AUTOMATIONSIZELIMIT		:		sprintf(message,"No more automation available");break;
		case MISSING_SPACE				:		sprintf(message,"Space missing");break;
		case IDENTIFIER_TOO_LONG		:		sprintf(message,"Identifier is too long");break;
		case AUTOMATIONLREADYEXISTS		:		sprintf(message,"Automation already defined");break;
		case BADAUTOMATIONNUMBER		:		sprintf(message,"Wrong automation number");break;
		case BAD_TRACK_STEP				:		sprintf(message,"Bad step value");break;
		default : sprintf(message,"Unknown Error 0x%x",gl_parserErrorCode);
	}

	prompt(message);
	sprintf(message,"");
	prompt(message);	
	gl_parserErrorCode=0;
}

/////////////////////////////////////////////////////////////////////////////
// getToken 
// return value TRUE if parsing correct, otherwise FALSE 
/////////////////////////////////////////////////////////////////////////////
unsigned char getToken(unsigned char* inputString, unsigned char* inputToken, unsigned char* stringPointer) {

	 unsigned char carCounter = 0;
	 unsigned char tokenCarPointer = 0;
	 unsigned char testToken[MAXSIZETOKEN];

	for (carCounter=0; carCounter < strlen(inputString); carCounter++) {
		if (inputString[carCounter]==' ') {
			(*stringPointer)++;
			continue; // remove space
		}
		testToken[tokenCarPointer++] = inputString[carCounter];

		(*stringPointer)++;
		if (!strncmp(testToken, inputToken, strlen(inputToken))) {
			return(TRUE);
		}

		// Error
		if (tokenCarPointer == ((strlen(inputToken)<MAXSIZETOKEN-1) ? strlen(inputToken):MAXSIZETOKEN - 1)) {
			gl_parserErrorCode = UNKNOWN_TOKEN;
			return(FALSE);
		}
	} 
	gl_parserErrorCode = UNKNOWN_TOKEN;
	return(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// getValue 
// return value TRUE if parsing correct, otherwise FALSE 
/////////////////////////////////////////////////////////////////////////////
unsigned char getValue(unsigned char* inputString, unsigned char* Value, unsigned char* stringPointer) {

	 unsigned char carCounter = 0;
	 unsigned char tokenCarPointer = 0;
	 unsigned char dataFound;
	 unsigned short number;

	errno = 0;
	while (inputString[carCounter] == ' ' && carCounter < strlen(inputString)) {
		(*stringPointer)++;
		carCounter++;
	}
	number = strtol_with_atoi(&inputString[carCounter],0);

	if (errno == ERANGE || errno ==EINVAL) dataFound = FALSE;
	else dataFound = TRUE;

	if (number >255) {
		errno == ERANGE;
		gl_parserErrorCode = BAD_NUMBER;
		return(FALSE);
	}
	
	if (dataFound==TRUE) {

		while (inputString[carCounter] != ' ' && carCounter < strlen(inputString)) {
			(*stringPointer)++;
			carCounter++;
		}

		*Value=(unsigned char)number;
		return(TRUE);
	}
	else {
		gl_parserErrorCode = NUMBER_MISSING;
		return(FALSE);
	}
}

/////////////////////////////////////////////////////////////////////////////
// Parser 
// return value TRUE if parsing correct, otherwise FALSE 
// Semantic analysis on values should be done on char content
/////////////////////////////////////////////////////////////////////////////
unsigned char parser(unsigned char* inputString, unsigned char* request) {

	 unsigned char stringPointer = 0;
	 unsigned char nextStringPointer = 0;
	 unsigned char keepStringPointer;
     unsigned char token[MAXSIZETOKEN];
	 unsigned char identCounter=0;
	 unsigned char getFirstSpace;

	initRequest(request);

	// get mode PROG or COM
	keepStringPointer = stringPointer;

	//PROG
	sprintf(token,PROG);
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_MODE] = PROGValue;

		// Get board number
		if (!getValue(&inputString[stringPointer], &request[REQ_BOARD_NUMBER], &stringPointer)) return(FALSE);
		nextStringPointer = stringPointer;
	}

	//COM
	stringPointer = keepStringPointer;
	sprintf(token,COM);
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_MODE] = COMValue;

		// Get board number
		if (!getValue(&inputString[stringPointer], &request[REQ_BOARD_NUMBER], &stringPointer)) return(FALSE);
		nextStringPointer = stringPointer;
	}

	// STOP
    sprintf(token,STOP);
	stringPointer = keepStringPointer;
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_GLOBAL_COMMAND] = STOPValue;
		request[REQ_BOARD_NUMBER] = gl_boardNumber;
		gl_parserErrorCode=0;
		return(TRUE);
	}

	// RUNALL 
	sprintf(token, RUNALL);
	stringPointer = keepStringPointer;
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_GLOBAL_COMMAND] = RUNALLValue;
		request[REQ_BOARD_NUMBER] = gl_boardNumber;
		gl_parserErrorCode=0;
		return(TRUE);
	}

	// RUN 
	sprintf(token,RUN);
	stringPointer = keepStringPointer;
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_GLOBAL_COMMAND] = RUNValue;

		// Get board number
		if (!getValue(&inputString[stringPointer], &request[REQ_BOARD_NUMBER], &stringPointer))return(FALSE);
		gl_parserErrorCode=0;
		return(TRUE);
	}

	// RESET
	sprintf(token,RESET);
	stringPointer = keepStringPointer;
	if (getToken(&inputString[stringPointer], token, &stringPointer)) {
		request[REQ_GLOBAL_COMMAND] = RESETValue;

		// Get board number
		if (!getValue(&inputString[stringPointer], &request[REQ_BOARD_NUMBER], &stringPointer))return(FALSE);
		gl_parserErrorCode=0;
		return(TRUE);
	}

	stringPointer = nextStringPointer;

	// Analyse Programing request
	if (request[REQ_MODE] == PROGValue) {

		// get DCC or ANA or GPIO or AUT or DEL
		keepStringPointer = stringPointer;

		// DCC
		sprintf(token,DCC);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_PROGRAM_REQUEST_SET_BOARD_MODE] = TRUE;
			request[REQ_PROGRAM_REQUEST_BOARD_MODE] = DCCValue;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		//ANA
		sprintf(token,ANA);
		stringPointer = keepStringPointer;
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_PROGRAM_REQUEST_SET_BOARD_MODE] = TRUE;
			request[REQ_PROGRAM_REQUEST_BOARD_MODE] = ANAValue;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		// GPIO
		sprintf(token,GPIO);
		stringPointer = keepStringPointer;
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_PROGRAM_REQUEST_SET_GPIO] = TRUE;

			// get GPIO number
			if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_SET_GPIO_NUMBER], &stringPointer)) return(FALSE);

			// get DIR
			sprintf(token,DIR);
			if (getToken(&inputString[stringPointer], token, &stringPointer)) {

				// get IN or OUT
				keepStringPointer = stringPointer;

				// IN
				sprintf(token,IN);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR] = INValue;
					gl_parserErrorCode=0;
					return(TRUE);
				}

				// OUT
				else {
					stringPointer = keepStringPointer;
					sprintf(token,OUT);
					if (getToken(&inputString[stringPointer], token, &stringPointer)) {
						request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR] = OUTValue;
						gl_parserErrorCode=0;
						return(TRUE);
					}
					else return(FALSE);
				}
			}
		}
		// AUT 
		stringPointer = keepStringPointer;
        sprintf(token,AUT);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_PROGRAM_REQUEST_SET_AUTOMATION] = TRUE;

			// GET AUTOMATION IDENTIFIER
			getFirstSpace=FALSE;
			while(identCounter<MAXSIZEIDENT) {
				if (inputString[stringPointer]!=' ') {
					if(identCounter==0 && getFirstSpace==FALSE) {
						gl_parserErrorCode = MISSING_SPACE;
						return(FALSE);
					}
					else request[REQ_PROGRAM_REQUEST_IDENT+identCounter++]=inputString[stringPointer++];
				}
				else {
					if (identCounter==0) {
						getFirstSpace=TRUE;
						stringPointer++; // Get first space
					}
					else {
						request[REQ_PROGRAM_REQUEST_IDENT+identCounter]='\0';
						break; // get second space
					}
				}
				if (identCounter==MAXSIZEIDENT) {
					gl_parserErrorCode = IDENTIFIER_TOO_LONG;
					return(FALSE);
				}
			}		

			//BOARD
			sprintf(token,BOARD);
			if (getToken(&inputString[stringPointer], token, &stringPointer)) {

				// get BOARD number
				int boardNumber;
				if (!getValue(&inputString[stringPointer], &boardNumber, &stringPointer)) return(FALSE);

				// get GPIO or TIMER or TRACK 
				keepStringPointer = stringPointer;

				// GPIO 
				sprintf(token,GPIO);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_GPIO_EVENT] = TRUE;
					request[REQ_PROGRAM_REQUEST_EVENT_BOARD_GPIO_NUMBER] = boardNumber;

					// get GPIO number
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_EVENT_GPIO_NUMBER], &stringPointer)) return(FALSE);

					// VAL
					sprintf(token,VAL);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get GPIO level
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_EVENT_GPIO_LEVEL], &stringPointer)) return(FALSE);
				}

				// TIMER 
				else {
					stringPointer = keepStringPointer;
					sprintf(token,TIMER);
					if (getToken(&inputString[stringPointer], token, &stringPointer)) {
						request[REQ_PROGRAM_REQUEST_TIMER_EVENT] = TRUE;
						request[REQ_PROGRAM_REQUEST_EVENT_BOARD_TIMER_NUMBER] = boardNumber;

						// get TIMER number
						if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_EVENT_TIMER_NUMBER], &stringPointer)) return(FALSE);
					}

					// TRACK
					else {
						stringPointer = keepStringPointer;
						sprintf(token,TRACK);
						if (getToken(&inputString[stringPointer], token, &stringPointer)) {
							request[REQ_PROGRAM_REQUEST_TRACK_EVENT] = TRUE;
							request[REQ_PROGRAM_REQUEST_EVENT_BOARD_TRACK_NUMBER] = boardNumber;

							// get TRACK number
							if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_EVENT_TRACK_NUMBER], &stringPointer)) return(FALSE);

							// STA
							sprintf(token,STA);
							if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

							// get ONTRACK or OFFTRACK 
							keepStringPointer = stringPointer;
							sprintf(token,ONTRACK);
							if (getToken(&inputString[stringPointer], token, &stringPointer)) {
								request[REQ_PROGRAM_REQUEST_EVENT_VEHICLE_STATUS] = ONTRACKValue;
							}
							else {
								stringPointer = keepStringPointer;
								sprintf(token,OFFTRACK);
								if (getToken(&inputString[stringPointer], token, &stringPointer)) {
									request[REQ_PROGRAM_REQUEST_EVENT_VEHICLE_STATUS] = OFFTRACKValue;
								}
								else return(FALSE);
							}
						}
						else return(FALSE);
					}
				}

				// ACT
				sprintf(token,ACT);
				if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

				// get GPIO or TIMER or LPO or TRACK or DCC
				keepStringPointer = stringPointer;

				// GPIO
				sprintf(token,GPIO);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_GPIO_SETTING] = TRUE;

					// get GPIO number
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_GPIO_SET_NUMBER], &stringPointer)) return(FALSE);

					// VAL
					sprintf(token,VAL);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get GPIO level
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_GPIO_SET_LEVEL], &stringPointer)) return(FALSE);
					gl_parserErrorCode=0;
					return(TRUE);
				}

				// TIMER
				stringPointer = keepStringPointer;
				sprintf(token,TIMER);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_TIMER_SETTING] = TRUE;

					// get TIMER number
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_TIMER_SET_NUMBER], &stringPointer)) return(FALSE);

					// VAL
					sprintf(token,VAL);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get TIMER delay
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_TIMER_SET_DELAY], &stringPointer)) return(FALSE);
					gl_parserErrorCode=0;
					return(TRUE);
				}


				// LPO
				stringPointer = keepStringPointer;
				sprintf(token,LPO);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_LPO_SETTING] = TRUE;

					// get LPO number
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGAM_REQUEST_ACTION_LPO_SET_NUMBER], &stringPointer)) return(FALSE);

					// VAL
					sprintf(token,VAL);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get LPO level
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_LPO_SET_LEVEL], &stringPointer)) return(FALSE);
					gl_parserErrorCode=0;
					return(TRUE);
				}

				// TRACK
				stringPointer = keepStringPointer;
				sprintf(token,TRACK);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_TRACK_SETTING] = TRUE;

					// get TRACK number
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_NUMBER], &stringPointer)) return(FALSE);

					// SPEED
					sprintf(token,SPEED);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get TRACK speed 
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_SPEED], &stringPointer)) return(FALSE);

					// get TRACK DIR

					// DIR
					sprintf(token,DIR);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get FORW or BACK 
					keepStringPointer = stringPointer;
					sprintf(token,FORW);
					if (getToken(&inputString[stringPointer], token, &stringPointer)) {
						request[REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_DIR] = FORWValue;
					}
					else {
						stringPointer = keepStringPointer;
						sprintf(token,BACK);
						if (getToken(&inputString[stringPointer], token, &stringPointer)) {
							request[REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_DIR] = BACKValue;
						}
						else return(FALSE);
					}

					// get STEP
					sprintf(token,STEP);
					if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

					// get STEP value 
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_STEP], &stringPointer)) return(FALSE);
					
					gl_parserErrorCode=0;
					return(TRUE);
				}

				// DCC
				stringPointer = keepStringPointer;
				sprintf(token,DCC);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_PROGRAM_REQUEST_DCC_SETTING] = TRUE;

					// Get DCC Address
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_DCC_ADDRESS_SETTING], &stringPointer))return(FALSE);

					// get DCC Command
					if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_ACTION_DCC_COMMAND_SETTING], &stringPointer))return(FALSE);
					gl_parserErrorCode=0;
					return(TRUE);
				}
				return(FALSE);
			}
			else return(FALSE);

		}

		// DEL
		stringPointer = keepStringPointer;
		sprintf(token,DEL);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_PROGRAM_REQUEST_DEL_AUTOMATION] = TRUE;

			// get Automation number
			if (!getValue(&inputString[stringPointer], &request[REQ_PROGRAM_REQUEST_AUTOMATION_NUMBER], &stringPointer)) return(FALSE);
			gl_parserErrorCode=0;
			return(TRUE);
		}

	}

	// Analyse Controling request
	else if (request[REQ_MODE] == COMValue) {
		//Get GPIO or LPO or TRACK or DCC or STOP or RUNALL or RU

		// GPIO
		keepStringPointer = stringPointer;
		sprintf(token,GPIO);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {

			request[REQ_COMMAND_REQUEST_SET_GPIO] = TRUE;

			// get GPIO number
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_GPIO_NUMBER], &stringPointer)) return(FALSE);

			// VAL
			sprintf(token,VAL);
			if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

			// get GPIO level
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_GPIO_LEVEL], &stringPointer)) return(FALSE);
			gl_parserErrorCode=0;
			return(TRUE);
		}

		// TIMER
		stringPointer = keepStringPointer;
		sprintf(token,TIMER);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {

			request[REQ_COMMAND_REQUEST_SET_TIMER] = TRUE;

			// get TIMER number
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_TIMER_NUMBER], &stringPointer)) return(FALSE);

			// VAL
			sprintf(token,VAL);
			if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

			// get TIMER delay
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_TIMER_DELAY], &stringPointer)) return(FALSE);
			gl_parserErrorCode=0;
			return(TRUE);
		}

		// LPO 
		stringPointer = keepStringPointer;
		sprintf(token,LPO);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {

			request[REQ_COMMAND_REQUEST_SET_LPO] = TRUE;

			// get LPO number
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_LPO_NUMBER], &stringPointer)) return(FALSE);

			// VAL
			sprintf(token,VAL);
			if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

			// get LPO level
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_LPO_LEVEL], &stringPointer)) return(FALSE);
			gl_parserErrorCode=0;
			return(TRUE);
		}

		// TRACK
		stringPointer = keepStringPointer;
		sprintf(token,TRACK);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {

			request[REQ_COMMAND_REQUEST_SET_TRACK] = TRUE;

			// get TRACK number
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_TRACK_NUMBER], &stringPointer)) return(FALSE);

			// SPEED
			sprintf(token,SPEED);
			if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

			// get TRACK speed 
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_TRACK_SPEED], &stringPointer)) return(FALSE);

			// get TRACK DIR

			// DIR
			sprintf(token,DIR);
			if (!getToken(&inputString[stringPointer], token, &stringPointer))	return(FALSE);

			// get FORW or BACK 
			keepStringPointer = stringPointer;
			sprintf(token,FORW);
			if (getToken(&inputString[stringPointer], token, &stringPointer)) {
				request[REQ_COMMAND_REQUEST_TRACK_DIR] = FORWValue;
			}
			else {
				stringPointer = keepStringPointer;
				sprintf(token,BACK);
				if (getToken(&inputString[stringPointer], token, &stringPointer)) {
					request[REQ_COMMAND_REQUEST_TRACK_DIR] = BACKValue;
				}
				else return(FALSE);
			}

			// STEP
			sprintf(token,STEP);
			if (!getToken(&inputString[stringPointer], token, &stringPointer)) return(FALSE);

			// get STEP value 
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_TRACK_STEP], &stringPointer)) return(FALSE);
			gl_parserErrorCode=0;
			return(TRUE);
		}

		// DCC
		stringPointer = keepStringPointer;
		sprintf(token,DCC);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_SET_DCC]= TRUE;

			// Get DCC Address
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_DCC_ADDRESS], &stringPointer)) return(FALSE);

			// get DCC Command
			if (!getValue(&inputString[stringPointer], &request[REQ_COMMAND_REQUEST_DCC_COMMAND], &stringPointer))  {
				return(FALSE);
			}
			gl_parserErrorCode=0;
			return(TRUE);
		}

		// GSTAT
		stringPointer = keepStringPointer;
		sprintf(token,GSTAT);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_GET_GPIO_STATUS] = TRUE;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		// LSTAT
		stringPointer = keepStringPointer;
		sprintf(token,LSTAT);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_GET_LPO_STATUS] = TRUE;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		// TSTAT
		stringPointer = keepStringPointer;
		sprintf(token,TSTAT);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_GET_TRACK_STATUS] = TRUE;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		// BSTAT
		stringPointer = keepStringPointer;
		sprintf(token,BSTAT);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_GET_BOARD_STATUS] = TRUE;
			gl_parserErrorCode=0;
			return(TRUE);
		}
		// AUTLIST
		stringPointer = keepStringPointer;
		sprintf(token,AUTLIST);
		if (getToken(&inputString[stringPointer], token, &stringPointer)) {
			request[REQ_COMMAND_REQUEST_GET_AUTOMATION_LIST] = TRUE;
			gl_parserErrorCode=0;
			return(TRUE);
		}
	}
	return(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// uncompressData 
/////////////////////////////////////////////////////////////////////////////
void uncompressData(unsigned char* data) {
	unsigned char dataCounter;
	unsigned char tmpDataCounter;
	unsigned char repeat;

	// Codage is simply X / Y where X is the number of Y. If X = 0 there is no more data

	tmpDataCounter=0;
	for(dataCounter=0;dataCounter<MAXTRAMESIZE-1;dataCounter+=2) {
		if(data[dataCounter]==0) break;
		for(repeat=0;repeat<data[dataCounter];repeat++) {
			gl_tmpBuffer[tmpDataCounter++]=data[dataCounter+1];
			if (tmpDataCounter>=MAXTRAMESIZE) break;
		}
	}
	for(dataCounter=0;dataCounter<tmpDataCounter;dataCounter++) data[dataCounter]=gl_tmpBuffer[dataCounter];
	for(;dataCounter<MAXTRAMESIZE;dataCounter++) data[dataCounter]=0; // should no happen
}

/////////////////////////////////////////////////////////////////////////////
// compressData 
/////////////////////////////////////////////////////////////////////////////
unsigned char compressData(unsigned char* data) {

	unsigned char tmpDataCounter;
	unsigned char dataCounter;
	unsigned char quantityValue;
	unsigned char curValue;

	dataCounter=0;
	tmpDataCounter=0;
	curValue=data[0];
	quantityValue=0;

	while(dataCounter<MAXTRAMESIZE) {
		while(data[dataCounter]==curValue) {
			quantityValue++;
			dataCounter++;
			if (dataCounter>=MAXTRAMESIZE) break;
		}
		if (tmpDataCounter<MAXTRAMESIZE)gl_tmpBuffer[tmpDataCounter++]=quantityValue;
		if (tmpDataCounter<MAXTRAMESIZE)gl_tmpBuffer[tmpDataCounter++]=curValue;
		if (tmpDataCounter>=MAXTRAMESIZE) {
			for(dataCounter=0;dataCounter<MAXTRAMESIZE;dataCounter++) data[dataCounter]=0;
			return(0); // We loose the trame, because we can't compress it, should never happen.....
		}
		curValue=data[dataCounter];
		quantityValue=0;
	}
	for(dataCounter=0;dataCounter<tmpDataCounter;dataCounter++) data[dataCounter]=gl_tmpBuffer[dataCounter];
	for(;dataCounter<MAXTRAMESIZE;dataCounter++) data[dataCounter]=0;

	return(tmpDataCounter);
}


/////////////////////////////////////////////////////////////////////////////
// setRequest 
/////////////////////////////////////////////////////////////////////////////
void setRequest(unsigned char* request, unsigned char* data,unsigned char init) {

    unsigned char dataCounter;

	if(init==FALSE){
		uncompressData(data);
		for(dataCounter=0;dataCounter<REQUESTSIZE;dataCounter++)request[dataCounter]=data[dataCounter];
	}
	else {
		for(dataCounter=0;dataCounter<REQUESTSIZE;dataCounter++)request[dataCounter]=0; 
	}	
}

/////////////////////////////////////////////////////////////////////////////
// getDataFromRequest 
/////////////////////////////////////////////////////////////////////////////
unsigned char getDataFromRequest(unsigned char* request, unsigned char* data) {

    unsigned char dataCounter;
	for(dataCounter=0;dataCounter<REQUESTSIZE;dataCounter++) data[dataCounter]=request[dataCounter];
	return(compressData(data));
}

/////////////////////////////////////////////////////////////////////////////
// InitRequest 
/////////////////////////////////////////////////////////////////////////////
void initRequest(unsigned char* request) {	
	setRequest(request,gl_dataStructure,TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// assignAutomation 
/////////////////////////////////////////////////////////////////////////////
void assignAutomation(char *request,unsigned char automationCounter) {

		// set request for command
		initRequest(request);

		request[REQ_MODE]=COMValue;
		request[REQ_BOARD_NUMBER]=gl_boardNumber;
		request[REQ_COMMAND_REQUEST_SET_GPIO] = gl_automation[automationCounter][AUTOMATION_COMMAND_SET_GPIO];
		request[REQ_COMMAND_REQUEST_GPIO_NUMBER] = gl_automation[automationCounter][AUTOMATION_COMMAND_GPIO_NUMBER];
		request[REQ_COMMAND_REQUEST_GPIO_LEVEL] = gl_automation[automationCounter][AUTOMATION_COMMAND_GPIO_LEVEL];

		request[REQ_COMMAND_REQUEST_SET_TIMER] = gl_automation[automationCounter][AUTOMATION_COMMAND_SET_TIMER];
		request[REQ_COMMAND_REQUEST_TIMER_NUMBER] = gl_automation[automationCounter][AUTOMATION_COMMAND_TIMER_NUMBER];
		request[REQ_COMMAND_REQUEST_TIMER_DELAY] = gl_automation[automationCounter][AUTOMATION_COMMAND_TIMER_DELAY];

		request[REQ_COMMAND_REQUEST_SET_LPO] = gl_automation[automationCounter][AUTOMATION_COMMAND_SET_LPO];
		request[REQ_COMMAND_REQUEST_LPO_NUMBER] = gl_automation[automationCounter][AUTOMATION_COMMAND_LPO_NUMBER];
		request[REQ_COMMAND_REQUEST_LPO_LEVEL] = gl_automation[automationCounter][AUTOMATION_COMMAND_LPO_LEVEL];

		request[REQ_COMMAND_REQUEST_SET_TRACK] = gl_automation[automationCounter][AUTOMATION_COMMAND_SET_TRACK];
		request[REQ_COMMAND_REQUEST_TRACK_NUMBER] = gl_automation[automationCounter][AUTOMATION_COMMAND_TRACK_NUMBER];
		request[REQ_COMMAND_REQUEST_TRACK_SPEED] = gl_automation[automationCounter][AUTOMATION_COMMAND_TRACK_SPEED];
		request[REQ_COMMAND_REQUEST_TRACK_DIR] = gl_automation[automationCounter][AUTOMATION_COMMAND_TRACK_DIR];
		request[REQ_COMMAND_REQUEST_TRACK_STEP] = gl_automation[automationCounter][AUTOMATION_COMMAND_TRACK_STEP];

		request[REQ_COMMAND_REQUEST_SET_DCC]= gl_automation[automationCounter][AUTOMATION_COMMAND_SET_DCC];
		request[REQ_COMMAND_REQUEST_DCC_ADDRESS] = gl_automation[automationCounter][AUTOMATION_COMMAND_DCC_ADDRESS];
		request[REQ_COMMAND_REQUEST_DCC_COMMAND] = gl_automation[automationCounter][AUTOMATION_COMMAND_DCC_COMMAND];
}

/////////////////////////////////////////////////////////////////////////////
// manageRequest 
/////////////////////////////////////////////////////////////////////////////
unsigned char manageRequest (unsigned char* request,unsigned char sendPrompt) {

	 unsigned char automationCounter;	 
	 unsigned char automationDataCounter;

	 unsigned char eventBoardTrackNumber;
	 unsigned char eventTrackNumber;

	 unsigned char eventVehicleStatus;
	 unsigned char statusCounter;
	 unsigned char dataCounter;

	 unsigned char eventBoardGPIONumber;
	 unsigned char eventGPIONumber;
	 unsigned char eventGPIOLevel;

	 unsigned char eventBoardTIMERNumber;
	 unsigned char eventTIMERNumber;

	 unsigned short adr; 
	 unsigned short adrLast;
	 unsigned char value;
	 unsigned char writeEEPROMCounter;
	 static unsigned char message[MAXMESSAGESIZE];
 	 static unsigned char onTrack[MAXSIZETOKEN];
	 static unsigned char offTrack[MAXSIZETOKEN];

     sprintf(message,"");

	// CHECK EVENT FIRST
	if (request[REQ_EVENT_REQUEST_TRACK_EVENT] == TRUE) {

		// Event from this board should be sent to the others
		if (request[REQ_BOARD_NUMBER] == gl_boardNumber) sendRequestToCAN(request);

		// Keep values as request struct should be reset
		eventBoardTrackNumber=request[REQ_EVENT_REQUEST_EVENT_BOARD_TRACK_NUMBER];
		eventTrackNumber=request[REQ_EVENT_REQUEST_EVENT_TRACK_NUMBER];
		eventVehicleStatus=request[REQ_EVENT_REQUEST_EVENT_VEHICLE_STATUS];

		for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {
				if(gl_automation[automationCounter][AUTOMATION_EVENT_TRACK_EVENT]==TRUE) {
				if (gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_BOARD_TRACK_NUMBER]==eventBoardTrackNumber &&
					gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_TRACK_NUMBER]==eventTrackNumber &&
					gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_VEHICLE_STATUS]==eventVehicleStatus) {

						// set request for command
						assignAutomation(request,automationCounter);
						if (manageRequest(request,FALSE)==FALSE) return (FALSE);
						else continue;	
					}
				}	
			}	
			return(TRUE);
	}
	else if (request[REQ_EVENT_REQUEST_GPIO_EVENT] == TRUE) {

		// Event from this board should be sent to the others
		if (request[REQ_BOARD_NUMBER] == gl_boardNumber) sendRequestToCAN(request);

		// Keep values as request struct should be reset
		eventBoardGPIONumber=request[REQ_EVENT_REQUEST_EVENT_BOARD_GPIO_NUMBER];
		eventGPIONumber=request[REQ_EVENT_REQUEST_EVENT_GPIO_NUMBER];
		eventGPIOLevel=request[REQ_EVENT_REQUEST_EVENT_GPIO_LEVEL];

		for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {
			if(gl_automation[automationCounter][AUTOMATION_EVENT_GPIO_EVENT]==TRUE) {
				if (gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_BOARD_GPIO_NUMBER]==eventBoardGPIONumber &&
					gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_GPIO_NUMBER]==eventGPIONumber &&
					gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_GPIO_LEVEL]==eventGPIOLevel) {

						// set request for command
						assignAutomation(request,automationCounter);
						if (manageRequest(request,FALSE)==FALSE) return (FALSE);
						else continue;	
					}
				}	
			}	
			return(TRUE);
	}

	else if (request[REQ_EVENT_REQUEST_TIMER_EVENT] == TRUE) {

		// Event from this board should be sent to the others
		if (request[REQ_BOARD_NUMBER] == gl_boardNumber) sendRequestToCAN(request);

		// Keep values as request struct should be reset
		eventBoardTIMERNumber=request[REQ_EVENT_REQUEST_EVENT_BOARD_TIMER_NUMBER];
		eventTIMERNumber=request[REQ_EVENT_REQUEST_EVENT_TIMER_NUMBER];

		for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {
			if(gl_automation[automationCounter][AUTOMATION_EVENT_TIMER_EVENT]==TRUE) {
				if (gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_BOARD_TIMER_NUMBER]==eventBoardTIMERNumber &&
					gl_automation[automationCounter][AUTOMATION_EVENT_EVENT_TIMER_NUMBER]==eventTIMERNumber) {

						// set request for command
						assignAutomation(request,automationCounter);
						if (manageRequest(request,FALSE)==FALSE) return (FALSE);
						else continue;		
					}
				}	
			}	
			return(TRUE);
	}

	//Global command

    switch (request[REQ_GLOBAL_COMMAND]) {
		case STOPValue: 
			gl_stopAll=TRUE;
			if (request[REQ_BOARD_NUMBER] == gl_boardNumber) sendRequestToCAN(request);
			if (sendPrompt==TRUE) prompt(message);
			return(TRUE);
		case RUNALLValue :
			gl_stopAll=FALSE;
			if (request[REQ_BOARD_NUMBER] == gl_boardNumber) sendRequestToCAN(request);
			if (sendPrompt==TRUE) prompt(message);
			return(TRUE);
		case RUNValue :
			if (request[REQ_BOARD_NUMBER] != gl_boardNumber && gl_master==TRUE) sendRequestToCAN(request);
			else if (request[REQ_BOARD_NUMBER] == gl_boardNumber) gl_stopAll=FALSE;
			if (sendPrompt==TRUE) prompt(message);
		 	return(TRUE); 
		case RESETValue :
			if (request[REQ_BOARD_NUMBER] != gl_boardNumber && gl_master==TRUE) sendRequestToCAN(request);
			else if (request[REQ_BOARD_NUMBER] == gl_boardNumber) ResetEEPROM();
			if (sendPrompt==TRUE) prompt(message);
		 	return(TRUE); 

		default : 

			// Check board number for command or program, on the master side, we forward the request on CAN bus
			if (request[REQ_BOARD_NUMBER] != gl_boardNumber){
				if (gl_master==TRUE) {

					// Send request to CAN
               	 	sendRequestToCAN(request);
					if (sendPrompt==TRUE) prompt(message);
				}
				return(TRUE); // Not for us
			}

			switch(request[REQ_MODE]) {
			case PROGValue: 
				if (request[REQ_PROGRAM_REQUEST_SET_BOARD_MODE]==TRUE) {
					if(request[REQ_PROGRAM_REQUEST_BOARD_MODE]==DCCValue) {
							gl_mutex=1;	setDcc(0,0); gl_mode=DCCValue; gl_mutex=0;
								
							// Save to EEPROM
							adr=(unsigned short)MODE_ADDRESS;
							WriteEEPROM(adr,gl_mode);
							if (sendPrompt==TRUE) prompt(message);
							return(TRUE);
					}
					else if(request[REQ_PROGRAM_REQUEST_BOARD_MODE]==ANAValue) {
							gl_mutex=1; gl_mode=ANAValue; gl_mutex=0;

							// Save to EEPROM
							adr=(unsigned short)MODE_ADDRESS;
							WriteEEPROM(adr,gl_mode);
							if (sendPrompt==TRUE) prompt(message);
							return(TRUE);
					}
					else {
						gl_parserErrorCode=MODE_MISSING;
						return(FALSE);
					}
				}
				if (request[REQ_PROGRAM_REQUEST_SET_GPIO] == TRUE) {		
					if (request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR]==INValue || request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR]==OUTValue) {		
						if (request[REQ_PROGRAM_REQUEST_SET_GPIO_NUMBER]>=0 && request[REQ_PROGRAM_REQUEST_SET_GPIO_NUMBER]<=4) {
							gl_mutex=1;
							switch(request[REQ_PROGRAM_REQUEST_SET_GPIO_NUMBER]) {
								case 0 :TRISDbits.RD1 = request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR];
										adr=(unsigned short)GPIO0DIR_ADDRESS;
										break;
								case 1 :TRISDbits.RD2 = request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR];
										adr=(unsigned short)GPIO1DIR_ADDRESS;
										break;
								case 2 :TRISDbits.RD3 = request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR];
										adr=(unsigned short)GPIO2DIR_ADDRESS;
										break;
								case 3 :TRISCbits.RC4 = request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR];
										adr=(unsigned short)GPIO3DIR_ADDRESS;
										break;
							}
							gl_mutex=0;
							WriteEEPROM(adr,request[REQ_PROGRAM_REQUEST_SET_GPIO_DIR]);
							if (sendPrompt==TRUE) prompt(message);
							return(TRUE);
						}
						else {
							gl_parserErrorCode=BAD_GPIO_NUMBER;
							return(FALSE);
						}	
					}
					else {
						gl_parserErrorCode=BAD_GPIO_DIR;
						return(FALSE);
					}											
				}
				if (request[REQ_PROGRAM_REQUEST_SET_AUTOMATION] == TRUE) {
					adr=AUTOMATION_ADDRESS+(gl_lastAutomation*AUTOMATIONSIZE);
					if (gl_lastAutomation>=MAXAUTOMATION || adr+AUTOMATIONSIZE>1024 ) {
						gl_parserErrorCode=AUTOMATIONSIZELIMIT;
						return(FALSE);
					}

					for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {
						if(!strcmp(&request[REQ_PROGRAM_REQUEST_IDENT],&(gl_automation[automationCounter][IDENT]))) {
							gl_parserErrorCode=AUTOMATIONLREADYEXISTS;
							return(FALSE);
						}
					}

					for(automationDataCounter=0;automationDataCounter<AUTOMATIONSIZE;automationDataCounter++) {
						WriteEEPROM(adr++,request[START_HERE_TO_COPY_FOR_AUTOMATION+automationDataCounter]);	
					}	

					gl_lastAutomation++;
					adr=(unsigned short)LASTAUTOMATION_ADDRESS;
					WriteEEPROM(adr,gl_lastAutomation);

					// Update form EEPROM
					ReadEEPROMConfig();	
					if (sendPrompt==TRUE) prompt(message);		
					return(TRUE);
				}		
				if (request[REQ_PROGRAM_REQUEST_DEL_AUTOMATION] == TRUE) {
					 if(request[REQ_PROGRAM_REQUEST_AUTOMATION_NUMBER]<gl_lastAutomation) {
						gl_lastAutomation--;
						if (gl_lastAutomation>0) {
							adr=(unsigned short)AUTOMATION_ADDRESS+request[REQ_PROGRAM_REQUEST_AUTOMATION_NUMBER]*AUTOMATIONSIZE;
							adrLast=(unsigned short)AUTOMATION_ADDRESS+gl_lastAutomation*AUTOMATIONSIZE;
							for(dataCounter=0;dataCounter<AUTOMATIONSIZE;dataCounter++) {
								ReadEEPROM(adrLast++,&value);WriteEEPROM(adr++,value);
							}
						}
					}
					else {
						gl_parserErrorCode=BADAUTOMATIONNUMBER;
						return(FALSE);
					}
					adr=(unsigned short)LASTAUTOMATION_ADDRESS;
					WriteEEPROM(adr,gl_lastAutomation);	

					// Update form EEPROM
					ReadEEPROMConfig();	
					if (sendPrompt==TRUE) prompt(message);		
					return(TRUE);	
				}

				break;
				
			case COMValue : 
				if (request[REQ_COMMAND_REQUEST_SET_GPIO]==TRUE) {
					if ((request[REQ_COMMAND_REQUEST_GPIO_NUMBER]==0 && TRISDbits.RD1==1) ||
						(request[REQ_COMMAND_REQUEST_GPIO_NUMBER]==1 && TRISDbits.RD2==1) ||
						(request[REQ_COMMAND_REQUEST_GPIO_NUMBER]==2 && TRISDbits.RD3==1) ||
						(request[REQ_COMMAND_REQUEST_GPIO_NUMBER]==3 && TRISCbits.RC4==1)) {
						gl_parserErrorCode=CANT_SET_GPIO_IN_INPUT_MODE;
						return(FALSE);
					}
					else if (request[REQ_COMMAND_REQUEST_GPIO_NUMBER]>=0 && request[REQ_COMMAND_REQUEST_GPIO_NUMBER]<=3) {
							if (request[REQ_COMMAND_REQUEST_GPIO_LEVEL]==0 ||request[REQ_COMMAND_REQUEST_GPIO_LEVEL]==1 ) {
								gl_mutex=1;	gl_GPIOchar[request[REQ_COMMAND_REQUEST_GPIO_NUMBER]]=request[REQ_COMMAND_REQUEST_GPIO_LEVEL]; gl_mutex=0;
								if (sendPrompt==TRUE) prompt(message);
								return(TRUE);
							}
							else {
								gl_parserErrorCode=BAD_GPIO_LEVEL;
								return(FALSE);
							}
						}
						else {
							gl_parserErrorCode=BAD_GPIO_NUMBER;
							return(FALSE);
						}				
				}
				else if (request[REQ_COMMAND_REQUEST_SET_TIMER]==TRUE) {
					 if (request[REQ_COMMAND_REQUEST_TIMER_NUMBER]>=0 && request[REQ_COMMAND_REQUEST_TIMER_NUMBER]<=MAXTIMER) {
							if (request[REQ_COMMAND_REQUEST_TIMER_DELAY]>0 && request[REQ_COMMAND_REQUEST_TIMER_DELAY]<=255 ) {
								gl_mutex=1;	gl_TIMERValue[request[REQ_COMMAND_REQUEST_TIMER_NUMBER]]=request[REQ_COMMAND_REQUEST_TIMER_DELAY]; gl_mutex=0;
								if (sendPrompt==TRUE) prompt(message);
								return(TRUE);
							}
							else {
								gl_parserErrorCode=BAD_TIMER_VALUE;
								return(FALSE);
							}
						}
						else {
							gl_parserErrorCode=BAD_TIMER_NUMBER;
							return(FALSE);
						}				
				}
				else if (request[REQ_COMMAND_REQUEST_SET_LPO] == TRUE) {
					if (request[REQ_COMMAND_REQUEST_LPO_NUMBER]>=0 && request[REQ_COMMAND_REQUEST_LPO_NUMBER]<=5) {
						if(request[REQ_COMMAND_REQUEST_LPO_LEVEL]==0 || request[REQ_COMMAND_REQUEST_LPO_LEVEL]==1) {
							gl_mutex=1;gl_OUTchar[request[REQ_COMMAND_REQUEST_LPO_NUMBER]]=!request[REQ_COMMAND_REQUEST_LPO_LEVEL];gl_mutex=0;
							if (sendPrompt==TRUE) prompt(message);
							return(TRUE);
						}
						else {
							gl_parserErrorCode=BAD_LPO_LEVEL;
							return(FALSE);
						}
					}
					else {
						gl_parserErrorCode=BAD_LPO_NUMBER;
						return(FALSE);
					}
				}
				else if (request[REQ_COMMAND_REQUEST_SET_TRACK] == TRUE) {
						if (gl_mode==DCCValue) {
							gl_parserErrorCode=BAD_MODE;
							return(FALSE);
						}
													
						if (request[REQ_COMMAND_REQUEST_TRACK_NUMBER]>=0 && request[REQ_COMMAND_REQUEST_TRACK_NUMBER]<=4) {
							if ((request[REQ_COMMAND_REQUEST_TRACK_SPEED]>=0 && request[REQ_COMMAND_REQUEST_TRACK_SPEED]<=15) &&
							    (request[REQ_COMMAND_REQUEST_TRACK_DIR]==FORWValue || request[REQ_COMMAND_REQUEST_TRACK_DIR]==BACKValue) &&
								(request[REQ_COMMAND_REQUEST_TRACK_STEP]>=0 && request[REQ_COMMAND_REQUEST_TRACK_STEP]<=15)) {
								gl_mutex=1;
								if (request[REQ_COMMAND_REQUEST_TRACK_NUMBER]==4) { // ALL
									for(request[REQ_COMMAND_REQUEST_TRACK_NUMBER]=0;request[REQ_COMMAND_REQUEST_TRACK_NUMBER]<4;request[REQ_COMMAND_REQUEST_TRACK_NUMBER]++) {
										gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=(int)(request[REQ_COMMAND_REQUEST_TRACK_SPEED] * (1+request[REQ_COMMAND_REQUEST_TRACK_STEP])) * ACC_RATE;
										gl_setStep[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=request[REQ_COMMAND_REQUEST_TRACK_STEP];
										if (request[REQ_COMMAND_REQUEST_TRACK_DIR]==BACKValue) gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=-gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]];
									}
								}
								else {
										gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=(int)(request[REQ_COMMAND_REQUEST_TRACK_SPEED] * (1+request[REQ_COMMAND_REQUEST_TRACK_STEP])) * ACC_RATE;
										gl_setStep[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=request[REQ_COMMAND_REQUEST_TRACK_STEP];
										if (request[REQ_COMMAND_REQUEST_TRACK_DIR]==BACKValue) gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]]=-gl_setPoint[request[REQ_COMMAND_REQUEST_TRACK_NUMBER]];
								}
								gl_mutex=0;
								if (sendPrompt==TRUE) prompt(message);
								return(TRUE);
							}
							else {
								if (!(request[REQ_COMMAND_REQUEST_TRACK_SPEED]>=0 && request[REQ_COMMAND_REQUEST_TRACK_SPEED]<=15)) {
									gl_parserErrorCode=BAD_TRACK_SPEED;
									return(FALSE);
								}
								if (!(request[REQ_COMMAND_REQUEST_TRACK_DIR]==FORWValue || request[REQ_COMMAND_REQUEST_TRACK_DIR]==BACKValue)) {
									gl_parserErrorCode=BAD_TRACK_DIR;
									return(FALSE);
								}
								if (!(request[REQ_COMMAND_REQUEST_TRACK_STEP]>=0 && request[REQ_COMMAND_REQUEST_TRACK_STEP]<=15)) {
									gl_parserErrorCode=BAD_TRACK_STEP;
									return(FALSE);
								}
							}	
						}
						else {								
							gl_parserErrorCode=BAD_TRACK_NUMBER;
							return(FALSE);
						}
				}
				else if (request[REQ_COMMAND_REQUEST_SET_DCC]== TRUE) {
						if (gl_mode==ANAValue) {
							gl_parserErrorCode=BAD_MODE;
							return(FALSE);
						}
						gl_mutex=1;
						setDcc(request[REQ_COMMAND_REQUEST_DCC_ADDRESS],request[REQ_COMMAND_REQUEST_DCC_COMMAND]);
						gl_mutex=0;
						if (sendPrompt==TRUE) prompt(message);
						return(TRUE);
				}
				else if (request[REQ_COMMAND_REQUEST_GET_AUTOMATION_LIST] == TRUE) {
					sprintf(message,"");
					if (sendPrompt==TRUE) prompt(message);
					for(automationCounter=0;automationCounter<gl_lastAutomation;automationCounter++) {
						sprintf(message,"%d %s",automationCounter,&(gl_automation[automationCounter][IDENT]));
						if (sendPrompt==TRUE) prompt(message);
					}
					sprintf(message,"");
					if (sendPrompt==TRUE) prompt(message);
					return(TRUE);
				}
				else if (request[REQ_COMMAND_REQUEST_GET_BOARD_STATUS] == TRUE) {
					if(gl_mode==ANAValue)sprintf(message,"ANA");
					else sprintf(message,"DCC");
					if (sendPrompt==TRUE) prompt(message);
					sprintf(message,"");
					if (sendPrompt==TRUE) prompt(message);	
					return(TRUE);
				}
				else if (request[REQ_COMMAND_REQUEST_GET_GPIO_STATUS] == TRUE) {
					if (sendPrompt==TRUE) {
						if(TRISDbits.RD1==0)sprintf(message,"GPIO 0 OUT");else sprintf(message,"GPIO 0 IN");
						sprintf(message,"%s VAL %d",message,gl_GPIOchar[0]);
						prompt(message);

						if(TRISDbits.RD2==0)sprintf(message,"GPIO 1 OUT");else sprintf(message,"GPIO 1 IN");
						sprintf(message,"%s VAL %d",message,gl_GPIOchar[1]);
						prompt(message);

						if(TRISDbits.RD3==0)sprintf(message,"GPIO 2 OUT");else sprintf(message,"GPIO 2 IN");
						sprintf(message,"%s VAL %d",message,gl_GPIOchar[2]);
						prompt(message);

						if(TRISCbits.RC4==0)sprintf(message,"GPIO 3 OUT");else sprintf(message,"GPIO 3 IN");
						sprintf(message,"%s VAL %d",message,gl_GPIOchar[3]);
						prompt(message);
		
						sprintf(message,"");
						prompt(message);
					}				
					return(TRUE);
				}
				else if (request[REQ_COMMAND_REQUEST_GET_LPO_STATUS] == TRUE) {
					for(statusCounter=0;statusCounter<6;statusCounter++) {
						if (gl_OUTchar[statusCounter]==0) sprintf(message,"LPO %d 1",statusCounter);else sprintf(message,"LPO %d 0",statusCounter);
						if (sendPrompt==TRUE) prompt(message);
					}
					sprintf(message,"");
					if (sendPrompt==TRUE) prompt(message);	
					return(TRUE);
				}
				else if (request[REQ_COMMAND_REQUEST_GET_TRACK_STATUS] == TRUE) {
					for(statusCounter=0;statusCounter<4;statusCounter++) {
						sprintf(onTrack,"ONTRACK");
						sprintf(offTrack,"OFFTRACK");
						if (gl_setPoint[statusCounter]>0) sprintf(message,"TRACK %d FORW SPEED %d %s",statusCounter,gl_setPoint[statusCounter]/((1+gl_setStep[statusCounter])*ACC_RATE),gl_OUTSTATchar[statusCounter]==0 ? offTrack : onTrack );
						else sprintf(message,"TRACK %d BACK SPEED %d %s",statusCounter,-gl_setPoint[statusCounter]/((1+gl_setStep[statusCounter])*ACC_RATE),gl_OUTSTATchar[statusCounter]==0 ? offTrack : onTrack );
						if (sendPrompt==TRUE) prompt(message);
					}
					sprintf(message,"");
					if (sendPrompt==TRUE) prompt(message);	
					return(TRUE);
				}		
				break;

			// NO ACTION TO PERFORM
			default : 
				if (sendPrompt==TRUE) prompt(message);
				return(TRUE);
		}
	}
}

//////////////////////////////////////////////////////////////////////////////
// UART
//////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////
// initUSART
//////////////////////////////////////////////////////////////////////////////
void initUSART() {

 	unsigned char 	readUSARTPointer;
	if (gl_master==FALSE)return;

    //RX and TX pin configuration
	TRISC=0b10110000; //  RC4, RC5, RC7 (RX) in (RC6 TX RS232 out, could be updated as standard GPIO in initSignal())

    // USART module configuration
    TXSTAbits.TXEN = 1; // Activate USART transmitter
    TXSTAbits.SYNC = 0; // Asynchronous mode
    TXSTAbits.BRGH = 1; // High Baud Rate Select bit
    RCSTAbits.SPEN = 1; // Enable serial module (TX and RX)
    RCSTAbits.CREN = 1; // Enable USART receiver
   
    // Speed register configuration
    SPBRG = ((_XTAL_FREQ / 16) / _BAUD) - 1; // _BAUD defined in main.h

	// init RS232 input buffer, event if it's not mandatory at all
	for(readUSARTPointer=0;readUSARTPointer<USARTBUFFERSIZE;readUSARTPointer++) {
		gl_receivedUSARTData[readUSARTPointer]=0;
	}
	gl_receivedUSARTPointer=0;
	gl_getDataUSARTPointer=0;

    PIE1bits.RCIE = 1;      // Enable USART interrupt reception
}
/*****************************************************************************/
/* sendUSART */
/*****************************************************************************/
void sendUSART(unsigned char data){

	if (gl_master==FALSE)return;

    // wait until transmission buffer is empty
    while (!TXSTAbits.TRMT);
	TXREG = data;
	while(!PIR1bits.TXIF);
}
/*****************************************************************************/
/* getInputRequestFromUSART() */
/*****************************************************************************/
unsigned char getInputRequestFromUSART(unsigned char *inputString,char *inputCounter) {

   unsigned char  getData;

	if (gl_master==FALSE)return;

	// Get Data from RS232
	if (gl_getDataUSARTPointer!=gl_receivedUSARTPointer) {
		getData=gl_receivedUSARTData[gl_getDataUSARTPointer];
		gl_receivedUSARTData[gl_getDataUSARTPointer++] = 0;

		if (gl_getDataUSARTPointer>=USARTBUFFERSIZE)gl_getDataUSARTPointer=0;

		//Echo
        if (getData!=0xD && *inputCounter<MAXINPUTSTRING-1) {
		
			if (getData==0x7F) {
				(*inputCounter)--;
				if (*inputCounter<0) *inputCounter=0;
				else sendUSART(getData); // Echo
			}
			else {
                inputString[(*inputCounter)++]=(unsigned char)toUpperCase(getData);
				sendUSART(getData); // Echo
			}
       }
        else {
			inputString[*inputCounter]='\0';	
			*inputCounter=0;
			return(TRUE);
		}
	}
	else {
		return(FALSE);
	}	
}
/*****************************************************************************/
/* prompt*/
/*****************************************************************************/
void prompt(unsigned char* message) {

	if (gl_master==TRUE) printf("\n\rMaster (%d) > %s",gl_boardNumber,message);
	else if(strlen(message)>0){
		printf("Board %d : %s",gl_boardNumber,message);
		if (gl_master==TRUE)prompt("");
	}
	flushOut();	
}
//////////////////////////////////////////////////////////////////////////////
// CAN
//////////////////////////////////////////////////////////////////////////////
/*****************************************************************************/
/* flushOut*/
/*****************************************************************************/
void flushOut() {
	_user_putc(ENDOFPRINTFTRAME);
}

/*****************************************************************************/
/* CANsendDelay*/
/*****************************************************************************/
void CANsendDelay() {
	unsigned short	delay;
	for(delay=0;delay<WAITDELAYTRAMECAN;delay++);
}

/*****************************************************************************/
/* _user_putc*/
/*****************************************************************************/
int _user_putc (char c) {

	unsigned long 	id;			// Id of sender
    unsigned char 	dataOut[8];	// DATA to CAN	
	unsigned char 	dataCounter;
	unsigned char	dataOutCounter;	
	unsigned char	trameComplete;

	BYTE dataLen; 				// Number of bytes transmitted in the message
	ECAN_RX_MSG_FLAGS flags; 	// Flags

	// On master board send to UART via standart putc()
	if (gl_master==TRUE){
		if (gl_inputCounter==0)sendUSART(c);
	}
	else {
		if (gl_outputBufferCounter<MAXMESSAGESIZE)gl_outputBuffer[gl_outputBufferCounter++]=c;

		// Send on CAN bus
	

		if (gl_outputBufferCounter==MAXMESSAGESIZE || c==ENDOFPRINTFTRAME) {
			dataLen=8;
			flags=ECAN_TX_STD_FRAME;
			id=gl_boardNumber;

			// header trame
			for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) dataOut[dataOutCounter]=TRAMEPRINTHEADER;

			// Synchro send
			while(gl_synchroSend >0);

			while(!ECANSendMessage(id,dataOut,dataLen,flags));
			CANsendDelay();

			// trame
			trameComplete=FALSE;
			dataCounter=0;
			while(dataCounter<MAXMESSAGESIZE) {
				for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) {
					if (dataCounter<gl_outputBufferCounter) {
						dataOut[dataOutCounter]=gl_outputBuffer[dataCounter++];
						if (dataOut[dataOutCounter]==ENDOFPRINTFTRAME) trameComplete=TRUE;
					}
					else {
						dataOut[dataOutCounter]=ENDOFPRINTFTRAME;
						if (dataCounter<MAXMESSAGESIZE)dataCounter++;
						trameComplete=TRUE;
					}
				}
				while(!ECANSendMessage(id,dataOut,dataLen,flags));
				CANsendDelay();

				if (trameComplete==TRUE) break;
			}
			gl_outputBufferCounter=0;

			// footer trame
			for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) dataOut[dataOutCounter]=TRAMEPRINTFOOTER;
			while(!ECANSendMessage(id,dataOut,dataLen,flags));
			CANsendDelay();
		}
	}
	return(c);
}

/*****************************************************************************/
/* sendRequestToCAN() */
/*****************************************************************************/
void sendRequestToCAN(unsigned char* request) {
	
	 unsigned long 	id;			// Id of sender
     unsigned char 	dataOut[8];	// DATA to CAN	
	 unsigned char 	dataCounter;
	 unsigned char	dataOutCounter;
	BYTE dataLen; 				// Number of bytes transmitted in the message
	ECAN_RX_MSG_FLAGS flags; 	// Flags
	unsigned char trameSize;

	// Convert request to dataOut using gl_dataStructure
	trameSize=getDataFromRequest(request,gl_dataStructure);

	dataLen=8;
	flags=ECAN_TX_STD_FRAME;
	dataCounter=0;
	id=gl_boardNumber;

	// header trame
	for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) {
		dataOut[dataOutCounter]=TRAMEREQUESTHEADER;
	}
			
	// Synchro send
	while(gl_synchroSend >0);

	while(!ECANSendMessage(id,dataOut,dataLen,flags));
	CANsendDelay();

	// trame
	while(dataCounter<trameSize) {
		for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) {
			if (dataCounter<trameSize) {
				dataOut[dataOutCounter]=gl_dataStructure[dataCounter++];
				if(dataCounter>=MAXTRAMESIZE) return; // Something wrong happened
			}
			else {
				dataOut[dataOutCounter]=0;
			}
		}
		while(!ECANSendMessage(id,dataOut,dataLen,flags));
		CANsendDelay();
	}

	// footer trame
	for(dataOutCounter=0;dataOutCounter<8;dataOutCounter++) {
		dataOut[dataOutCounter]=TRAMEREQUESTFOOTER;
	}
	while(!ECANSendMessage(id,dataOut,dataLen,flags));
	CANsendDelay();
}
/*****************************************************************************/
/* getInputRequestFromCAN() */
/*****************************************************************************/
unsigned char getInputRequestFromCAN(unsigned char* request) {
	
	unsigned char	requestHeaderTrameDetected=0;
	unsigned char	printHeaderTrameDetected=0;	
	unsigned char	requestFooterTrameDetected=0;
	unsigned char	printFooterTrameDetected=0;
	char			requestTrameEnd;
	char			printTrameEnd;

	unsigned char	dataInCounter;
	unsigned char	dataStructureCounter;
	static char message[MAXMESSAGESIZE];

	sprintf(message,"");
	while (gl_getDataCANPointer!=gl_InputBufferPointer) {
	
			if (gl_inputBuffer[gl_getDataCANPointer]==TRAMEREQUESTHEADER) requestHeaderTrameDetected++;	else requestHeaderTrameDetected=0;
			if (gl_inputBuffer[gl_getDataCANPointer]==TRAMEREQUESTFOOTER)	requestFooterTrameDetected++;	else requestFooterTrameDetected=0;

			if (gl_inputBuffer[gl_getDataCANPointer]==TRAMEPRINTHEADER) 	printHeaderTrameDetected++;		else printHeaderTrameDetected=0;				
			if (gl_inputBuffer[gl_getDataCANPointer]==TRAMEPRINTFOOTER) 	printFooterTrameDetected++;		else printFooterTrameDetected=0;

			// REQUEST HEADER
			if (requestHeaderTrameDetected==8) {
				gl_canMode=CAN_REQUEST;
				requestHeaderTrameDetected=0;
				gl_requestTrameStart=gl_getDataCANPointer+1;
				if (gl_requestTrameStart>=MAXTRAMESIZE)gl_requestTrameStart=0;
			}
			
			// PRINT HEADER
			else if (printHeaderTrameDetected==8) {
				gl_canMode=CAN_PRINT;
				printHeaderTrameDetected=0;
				gl_printTrameStart=gl_getDataCANPointer+1;
				if (gl_printTrameStart>=MAXTRAMESIZE)gl_printTrameStart=0;
			}

			// REQUEST FOOTER
			else if (requestFooterTrameDetected==8 && gl_canMode==CAN_REQUEST) {
				requestTrameEnd=gl_getDataCANPointer-9;
				if (requestTrameEnd<0)requestTrameEnd+=MAXTRAMESIZE;
				dataInCounter=gl_requestTrameStart;
				dataStructureCounter=0;
				while(dataInCounter!=requestTrameEnd) {
					gl_dataStructure[dataStructureCounter++]=gl_inputBuffer[dataInCounter++];
					if (dataInCounter>=MAXTRAMESIZE)dataInCounter=0;
				}
				setRequest(request,gl_dataStructure,FALSE);
				gl_canMode=CAN_UNKNOWN; // If more data arrive.... we delete this trame
				gl_getDataCANPointer++;		
				if (gl_getDataCANPointer>=MAXTRAMESIZE)gl_getDataCANPointer=0;
				return(TRUE); // Mean request available to proceed
			}
				
			// PRINT FOOTER	
			else if (printFooterTrameDetected==8 && gl_canMode==CAN_PRINT) {
				printTrameEnd=gl_getDataCANPointer-9;
				if (printTrameEnd<0)printTrameEnd+=MAXTRAMESIZE;
				dataInCounter=gl_printTrameStart;
				while(dataInCounter!=printTrameEnd) {
					printf("%c",gl_inputBuffer[dataInCounter++]);	
					if (dataInCounter>=MAXTRAMESIZE)dataInCounter=0;
				}
				prompt(message);
				gl_canMode=CAN_UNKNOWN; // If more data arrive.... we continue to get data
				gl_getDataCANPointer++;		
				if (gl_getDataCANPointer>=MAXTRAMESIZE)gl_getDataCANPointer=0;
				return(FALSE); // Mean no more data to print
			}	
		
			// read new data
			gl_getDataCANPointer++;		
			if (gl_getDataCANPointer>=MAXTRAMESIZE)gl_getDataCANPointer=0;					
	}
	return(FALSE); // Nothing to do
}

//////////////////////////////////////////////////////////////////////////////
// INTERRUPT AND SIGNAL MANAGEMENT
//////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// setDcc
/////////////////////////////////////////////////////////////////////////////
void setDcc(unsigned char address, unsigned char command) {

	 unsigned char i;			
	 unsigned char bitNumber; 	
	 unsigned char control; 		

	control=address ^ command; // Control
	bitNumber=0;

	// PREAMBULE
    for(i=0;i<PREAMBLE_SIZE;i++) {
		gl_dcc[bitNumber++]=1;
	}
	// 0
	gl_dcc[bitNumber++]=0;

	// ADDRESS
    for(i=0;i<8;i++) {
		gl_dcc[bitNumber++]=address >> (7-i) & 1;
	}
	// 0
	gl_dcc[bitNumber++]=0;

	// COMMAND
    for(i=0;i<8;i++) {
		gl_dcc[bitNumber++]=command >> (7-i) & 1;
	}
	// 0
	gl_dcc[bitNumber++]=0;

	// CONTROL
    for(i=0;i<8;i++) {
		gl_dcc[bitNumber++]=control >> (7-i) & 1;
	}
	// 1
	gl_dcc[bitNumber++]=1;			
	gl_dcc[bitNumber++]=1; // Only one is enough, but in case of....
}

//////////////////////////////////////////////////////////////////////////////
// function SetPort
//////////////////////////////////////////////////////////////////////////////
void setPort(){

    unsigned char OUTCounter;
	unsigned char myPortA; // used to better synchronised output updates
	unsigned char myPortB; // used to better synchronised output updates
	unsigned char myPortC; // used to better synchronised output updates
	unsigned char myPortD; // used to better synchronised output updates
	unsigned char myPortE; // used to better synchronised output updates

	if (gl_stopAll==TRUE) {
		gl_S1T0char=0; gl_S2T0char=0;
		gl_S1T1char=0; gl_S2T1char=0;
		gl_S1T2char=0; gl_S2T2char=0;
		gl_S1T3char=0; gl_S2T3char=0;	
		for(OUTCounter=0;OUTCounter<6;OUTCounter++) gl_OUTchar[OUTCounter]=1;
	}

    myPortA=(gl_S1T0char<<4) + (gl_OUTSTATchar[0]<<5) + (gl_S1T1char<<6) + (gl_S2T0char<<7);
    myPortB=(gl_OUTchar[2]) + (gl_OUTchar[3]<<1) + (gl_OUTchar[4]<<4) + (gl_OUTchar[5]<<5);
	myPortC=(gl_S2T1char) + (gl_S1T2char<<1) + (gl_S2T2char<<2) + (gl_S1T3char<<3) +(TRISCbits.RC4==0 ? gl_GPIOchar[3] <<4 : 0);
	myPortD=(gl_S2T3char) + (TRISDbits.RD1==0 ? gl_GPIOchar[0] <<1 :0) + (TRISDbits.RD2==0 ? gl_GPIOchar[1] <<2:0) +(TRISDbits.RD3==0 ? gl_GPIOchar[2] <<3:0) + (gl_OUTchar[0]<<6) +  (gl_OUTchar[1]<<7);
    myPortE= (gl_OUTSTATchar[1]) + (gl_OUTSTATchar[2]<<1) + (gl_OUTSTATchar[3]<<2);


	LATA=myPortA;
    LATB=myPortB;
    LATC=myPortC;
    LATD=myPortD;
    LATE=myPortE;
}

/*****************************************************************************/
/* interrupt_at_high_vector */
/*****************************************************************************/
#pragma code high_vector=0x08
void interrupt_at_high_vector(void){
    _asm goto high_isr _endasm
}
#pragma code
/****************************************************************************/
/* high_isr */
/****************************************************************************/
#pragma interrupt high_isr
void high_isr(void){

	BYTE dataLen; 				// Number of bytes transmitted in the message
	ECAN_RX_MSG_FLAGS flags; 	// Flags
	unsigned long 	id;			// Id of sender	

	if(PIR3bits.RXB0IF ||PIR3bits.RXB1IF) {
		while(ECANReceiveMessage(&id, &gl_inputBuffer[gl_InputBufferPointer], &dataLen, &flags)) {	
			gl_InputBufferPointer+=dataLen;
			if(gl_InputBufferPointer>=MAXTRAMESIZE)gl_InputBufferPointer-=MAXTRAMESIZE;
		}
		gl_synchroSend=gl_boardNumber*SYNCHROSENDDELAY;
	}
	
	if (gl_master==FALSE)return;

    // Check if interrupt originates from USART reception
    if (PIR1bits.RCIF)
    {
        // Read received data
        gl_receivedUSARTData[gl_receivedUSARTPointer++] = RCREG;
		if (gl_receivedUSARTPointer>=USARTBUFFERSIZE)gl_receivedUSARTPointer=0;
    }
}
#pragma code
/*****************************************************************************/
/* low_interrupt */
/*****************************************************************************/
#pragma code low_vector=0x18
void low_interrupt (){
    _asm goto low_isr _endasm
}
#pragma code
/*****************************************************************************/
/* low_isr */
/*****************************************************************************/
#pragma interruptlow low_isr
void low_isr(void){
	  unsigned char 	bitStateCounter;
	  unsigned char 	delay;
	  unsigned char 	selectBitDelay;
	  unsigned char 	bitNumber;
	  unsigned char 	bitValue;
	  unsigned short 	ADC;
	  int				calculNewSpeed;

	// Synchro send
	if(gl_synchroSend>0)gl_synchroSend--;
	
	if (!gl_mutex) {

		// GPIO IN Detection
		if(TRISDbits.RD1==1 && PORTDbits.RD1!=gl_GPIOchar[0]){
			gl_GPIOstabilized[0]++;
			if (gl_GPIOstabilized[0]>GPIOTHRESHOLD) {
				gl_GPIOchar[0]=PORTDbits.RD1;
				gl_GPIONotification[0]=TRUE;
				gl_GPIOstabilized[0]=0;
			}
		}
		else gl_GPIOstabilized[0]=0;

		if(TRISDbits.RD2==1 &&PORTDbits.RD2!=gl_GPIOchar[1]){
			gl_GPIOstabilized[1]++;
			if (gl_GPIOstabilized[1]>GPIOTHRESHOLD) {
				gl_GPIOchar[1]=PORTDbits.RD2;
				gl_GPIONotification[1]=TRUE;
				gl_GPIOstabilized[1]=0;
			}
		}
		else gl_GPIOstabilized[1]=0;

		if(TRISDbits.RD3==1 & PORTDbits.RD3!=gl_GPIOchar[2]){
			gl_GPIOstabilized[2]++;
			if (gl_GPIOstabilized[2]>GPIOTHRESHOLD) {
				gl_GPIOchar[2]=PORTDbits.RD3;
				gl_GPIONotification[2]=TRUE;
				gl_GPIOstabilized[2]=0;
			}
		}
		else gl_GPIOstabilized[2]=0;

		if(TRISCbits.RC4==1 & PORTCbits.RC4!=gl_GPIOchar[3]){
			gl_GPIOstabilized[3]++;
			if (gl_GPIOstabilized[3]>GPIOTHRESHOLD) {
				gl_GPIOchar[3]=PORTCbits.RC4;
				gl_GPIONotification[2]=TRUE;
				gl_GPIOstabilized[3]=0;
			}
		}
		else gl_GPIOstabilized[3]=0;

		if (gl_stopAll==FALSE) {

			// TIMER
			gl_timer--;
			if (gl_timer==0) {
				gl_timer=INITTIMERVALUE;
				if (gl_TIMERValue[gl_timerNumber]>0){
					gl_TIMERValue[gl_timerNumber]--;
					if (gl_TIMERValue[gl_timerNumber]==0)gl_TIMERNotification[gl_timerNumber]=TRUE;
				}
				gl_timerNumber++;
				if(gl_timerNumber>MAXTIMER)gl_timerNumber=0;
			}

			gl_trackNumber=gl_trackNumber+1;
			if (gl_trackNumber>3)gl_trackNumber=0;
	
			//////////// MODE ANALOG ////////////////
			if(gl_mode==ANAValue) {
				gl_speedCounter++;
				if (gl_speedCounter>MAX_STEP_COUNTER) {
		 			gl_speedCounter=1;
				}

				if (gl_curSpeed[gl_trackNumber]>gl_setPoint[gl_trackNumber]) {
					gl_curSpeed[gl_trackNumber]--;
				}
				else if (gl_curSpeed[gl_trackNumber]<gl_setPoint[gl_trackNumber]) {
					gl_curSpeed[gl_trackNumber]++;
				}
										
				if (gl_curSpeed[gl_trackNumber]>0) {
					calculNewSpeed = gl_curSpeed[gl_trackNumber]/((1+gl_setStep[gl_trackNumber])*ACC_RATE);		
					gl_speed[gl_trackNumber]=(unsigned char) calculNewSpeed;
					gl_direction[gl_trackNumber]=TRACK_FORWARD;
				}
				else if (gl_curSpeed[gl_trackNumber]<0) {
					calculNewSpeed = gl_curSpeed[gl_trackNumber]/((1+gl_setStep[gl_trackNumber])*ACC_RATE);
					calculNewSpeed=-calculNewSpeed;			
					gl_speed[gl_trackNumber]=(unsigned char)calculNewSpeed;
					gl_direction[gl_trackNumber]=TRACK_BACKWARD;
				}
				else gl_direction[gl_trackNumber]==TRACK_STOP;

				if (gl_speed[gl_trackNumber]>=gl_speedCounter) {
					if (gl_direction[gl_trackNumber]==TRACK_FORWARD) {
			    		switch (gl_trackNumber) {
			           		case 0:gl_S1T0char=1; gl_S2T0char=0;break;
			          	 	case 1:gl_S1T1char=1; gl_S2T1char=0;break;
			           	 	case 2:gl_S1T2char=1; gl_S2T2char=0;break;
			           		case 3:gl_S1T3char=1; gl_S2T3char=0;break;
			        	}
			    	}
			    	if (gl_direction[gl_trackNumber]==TRACK_BACKWARD) {
			        	switch (gl_trackNumber) {
			            	case 0:gl_S1T0char=0; gl_S2T0char=1;break;
			            	case 1:gl_S1T1char=0; gl_S2T1char=1;break;
			            	case 2:gl_S1T2char=0; gl_S2T2char=1;break;
			            	case 3:gl_S1T3char=0; gl_S2T3char=1;break;
			        	}
			    	}
			    	if (gl_direction[gl_trackNumber]==TRACK_STOP) {
			        	switch (gl_trackNumber) {
			            	case 0:gl_S1T0char=0; gl_S2T0char=0;break;
			            	case 1:gl_S1T1char=0; gl_S2T1char=0;break;
			            	case 2:gl_S1T2char=0; gl_S2T2char=0;break;
			            	case 3:gl_S1T3char=0; gl_S2T3char=0;break;
			        	}
			    	}
				}
				else {
					switch (gl_trackNumber) {
			        	case 0:gl_S1T0char=0; gl_S2T0char=0;break;
			        	case 1:gl_S1T1char=0; gl_S2T1char=0;break;
			        	case 2:gl_S1T2char=0; gl_S2T2char=0;break;
			        	case 3:gl_S1T3char=0; gl_S2T3char=0;break;
			    	}
				}

				setPort();
			}

			//////////// MODE DIGITAL ////////////////

			if(gl_mode==DCCValue && gl_dcc_ready==0) {		

				for (bitStateCounter=0;bitStateCounter<FRAME_SIZE;bitStateCounter++) {

					if (gl_dcc[bitStateCounter]==0) selectBitDelay=DCC_0;
					else selectBitDelay=DCC_1;
							
					gl_S1T0char=0;gl_S1T1char=0;
					gl_S1T2char=0;gl_S1T3char=0;
					gl_S2T0char=1;gl_S2T1char=1;
					gl_S2T2char=1;gl_S2T3char=1;
            		setPort();
					for (delay=0;delay<selectBitDelay;delay++);
	
		    		gl_S2T0char=0;gl_S2T1char=0;
					gl_S2T2char=0;gl_S2T3char=0;
					gl_S1T0char=1;gl_S1T1char=1;
					gl_S1T2char=1;gl_S1T3char=1;
            		setPort();
					for (delay=0;delay<selectBitDelay;delay++);
				}

				gl_S1T0char=0; gl_S2T0char=1;	
				gl_S1T1char=0; gl_S2T1char=1;
				gl_S1T2char=0; gl_S2T2char=1;	
				gl_S1T3char=0; gl_S2T3char=1;
        		setPort();
				for (delay=0;delay<selectBitDelay;delay++);	
				for (bitStateCounter=0;bitStateCounter<FRAME_SIZE;bitStateCounter++)gl_dcc[bitStateCounter]=1;
			}
			gl_dcc_ready--;
			if (gl_dcc_ready<0) gl_dcc_ready=INITWAITDCCCOUNTER;
			setPort();

			// TRACK DETECTION 

			switch(gl_trackNumber) {
				case 0 : ADCON0=CURT0;break;
		    	case 1 : ADCON0=CURT1;break;
		    	case 2 : ADCON0=CURT2;break;
		   		case 3 : ADCON0=CURT3;break;
			}
			// NEED TO GET LOW VOLTAGE VALUE WHEN TRACK IS OFF FOR CALIBRATION AT POWER ON
	 		if (gl_calibration==TRUE) {
				ADCON0bits.GO = 1;                            // ADCON0.GODONE = 1 
				while(ADCON0bits.GO == 1);                    // wait till GODONE bit is zero
				ADC = 0;
				ADC = ADRESH;    //Read converted result 
				ADC = (ADC<<8) + ADRESL;
				gl_average[gl_trackNumber]=(SAMPLEFORCALIBRATION*gl_average[gl_trackNumber]+ADC)/(SAMPLEFORCALIBRATION+1);
				if (gl_noVehicule[gl_trackNumber]>gl_average[gl_trackNumber])gl_noVehicule[gl_trackNumber]=gl_average[gl_trackNumber];
			}

			if((gl_speed[gl_trackNumber]==gl_speedCounter && gl_mode==ANAValue) || (gl_dcc_ready==INITWAITDCCCOUNTER && gl_mode==DCCValue)) { // ONLY WHEN POWER ON
				ADCON0bits.GO = 1;                            // ADCON0.GODONE = 1 
				while(ADCON0bits.GO == 1);                    // wait till GODONE bit is zero
				ADC = 0;
				ADC = ADRESH;    //Read converted result 
				ADC = (ADC<<8) + ADRESL;

				if (gl_average[gl_trackNumber]<ADC) gl_average[gl_trackNumber]=ADC; // TRAP THE EVENT
				else gl_average[gl_trackNumber]=(SAMPLEFORAVERAGE*gl_average[gl_trackNumber]+ADC)/(SAMPLEFORAVERAGE+1);

				if ((10*gl_average[gl_trackNumber]>(10+HYSTERERISHIGH)*gl_noVehicule[gl_trackNumber]) && (gl_OUTSTATchar[gl_trackNumber]==0)  && (gl_trackNotification[gl_trackNumber]==FALSE)) {
					gl_OUTSTATchar[gl_trackNumber]=1;
					gl_trackNotification[gl_trackNumber]=TRUE;
				}
				else if ((10*gl_average[gl_trackNumber]<(10+HYSTERERISLOW)*gl_noVehicule[gl_trackNumber]) && (gl_OUTSTATchar[gl_trackNumber]==1) && (gl_trackNotification[gl_trackNumber]==FALSE)) {
					gl_OUTSTATchar[gl_trackNumber]=0;
					gl_trackNotification[gl_trackNumber]=TRUE;
				}
			} 
		}
		else setPort();
	}

    // INTERRUPT RESET
    if(INTCONbits.TMR0IF==1){
	    INTCONbits.TMR0IF = 0;
		T0CONbits.PSA			= 0;   // Timer0 prescaler is assigned
		T0CONbits.T0PS0			= 0;   // Prescale value 
		T0CONbits.T0PS1			= 0;   // Prescale value 
		T0CONbits.T0PS2			= 0;   // Prescale value 
    }
}
#pragma code

//////////////////////////////////////////////////////////////////////////////
// CODE INITIALISATION
//////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
/* initSignal */
/*****************************************************************************/
void initSignal() {

    unsigned char trackNumber;
	unsigned char OUTCounter;	
	unsigned char GPIOCounter;
	unsigned char TIMERCounter;

	gl_mutex=1; // should not be necessary because interrupt not yet enabled

    ADCON1 	= 0x0B; // AN0 to AN3 
    ADCON2 	= 0x9D; 
	TRISA 	= 0b00001111; // PORTA AN0 to AN3 in 
	LATA 	= 0;

    TRISB	= 0b00001000; // RB3 in for CAN bus
    PORTB	= 0;
	LATB	= 0;

    TRISC	= 0b11110000; //  RC4, RC6, RC5, RC7 (RX) in (RC6 TX RS232 could be updated in initUSART() to be out)
    PORTC	= 0;
	LATC	= 0;

    TRISE	= 0; // All out + PORTD setting
    PORTE	= 0;
	LATE	= 0;
	CMCON 	= 7;

    TRISD	= 0b00111110; //  RD1, RD2, RD3, RD4, RD5 in
    PORTD	= 0;
	ECCP1CON = 0; // Disable ENHANCED CAPTURE/COMPARE/PWM (ECCP1) MODULE
	LATD	= 0;


    for(trackNumber=0;trackNumber<4;trackNumber++) {
      gl_average[trackNumber]=0;
	  gl_noVehicule[trackNumber]=0xFF;
      gl_speed[trackNumber]=0;
      gl_direction[trackNumber]=0;
      gl_setPoint[trackNumber]=0;
      gl_setStep[trackNumber]=0;
      gl_curSpeed[trackNumber]=0;
	  gl_OUTSTATchar[trackNumber]=0;
	  gl_trackNotification[trackNumber]=FALSE;
    }

	for(OUTCounter=0;OUTCounter<6;OUTCounter++) gl_OUTchar[OUTCounter]=1;


	for(GPIOCounter=0;GPIOCounter<4;GPIOCounter++) {
		gl_GPIOchar[GPIOCounter]=0;
		gl_GPIOstabilized[GPIOCounter]=0;
		gl_GPIONotification[GPIOCounter]=FALSE;
	}
	for(TIMERCounter=0;TIMERCounter<MAXTIMER;TIMERCounter++) {
		gl_TIMERValue[TIMERCounter]=0;
		gl_TIMERNotification[TIMERCounter]=FALSE;
	}
	gl_timerNumber=0;
	gl_timer=0;
		

	// DCC TEMPO BETWEEN TWO TRAMES
    gl_dcc_ready=INITWAITDCCCOUNTER;

	// Start
	gl_calibration=FALSE;
	gl_stopAll=FALSE;
	gl_trackNumber=0;

	// Detect master board
	if (IN4 & IN3 & IN0) gl_master=TRUE;
	else gl_master=FALSE;
	
	// Get board number
	gl_boardNumber=IN4 + 2*IN3 + 4*IN0 + 8*IN1 + 16*IN2;

	// Init structure 
	gl_outputBufferCounter=0;
	setRequest(&gl_request,gl_dataStructure,TRUE);

	// Update form EEPROM
	gl_mutex=0;
	ReadEEPROMConfig();

}

/*****************************************************************************/
/* PIC18FMainSettings */
/*****************************************************************************/
void PIC18FMainSettings (){

    // PIC setting and enable interrupts
    OSCCON                  = 0x70;  // no pre-divider => 8MHz 
    OSCTUNE                 = 0x40;  // PLL *4 => 32MHz 

    T0CONbits.T08BIT        = 1;   // 8-bit timer 
    T0CONbits.T0CS          = 0;   // increment on instruction cycle input
    T0CONbits.T0SE          = 0;   // increment on low--> high transition of clock
    T0CONbits.PSA           = 1;   // T0 prescaler  assigned to 1:1
    RCONbits.IPEN           = 1;   // Enable Interrupt Priorities
    INTCONbits.GIEL         = 1;   // Enable Low Priority Interrupt
    INTCONbits.GIEH         = 0;   // Enable high priority interrupts
    INTCONbits.GIE          = 1;   // Enable Global Interrupts            
    INTCONbits.PEIE         = 1;   // Enable device interrupts
    INTCONbits.TMR0IE       = 1;   // Enable Timer0 Interrupt
    INTCON2bits.TMR0IP      = 0;   // TMR0 set to low Priority Interrupt
    INTCONbits.TMR0IF       = 0;   // T0 int flag bit cleared before starting
    T0CONbits.TMR0ON        = 1;   // timer0 START
}

/*****************************************************************************/
/* init */
/*****************************************************************************/
void init() {
 

    // Signal
     initSignal();

    // RS232
	initUSART(); // Serial USART init on master board only
    
    // ECAN
    TRISBbits.TRISB3 = 1; // CANRX input setting
	gl_InputBufferPointer=0;
	gl_getDataCANPointer=0;
	gl_canMode=CAN_UNKNOWN;

    ECANInitialize(); // init ECAN
	PIE3bits.RXB0IE=1; // enable interrupt for CAN
	PIE3bits.RXB1IE=1; // enable interrupt for CAN

    // Main settings + Start timer
    PIC18FMainSettings(); 

	// Use user putc function
	stdout = _H_USER;

}

/*****************************************************************************/
/* calibration */
/*****************************************************************************/
void calibration() {

	 unsigned short trackNumberCalibration;
	 unsigned char 	trackNumber;

	gl_mutex=1;	gl_calibration=TRUE; gl_mutex = 0;
	for(trackNumberCalibration=0;trackNumberCalibration<TIMECALIBRATION;trackNumberCalibration++);

    for(trackNumber=0;trackNumber<4;trackNumber++) {
	  gl_noVehicule[trackNumber]=0xFF;
	}
	for(trackNumberCalibration=0;trackNumberCalibration<TIMECALIBRATION;trackNumberCalibration++);	
	gl_mutex=1;	gl_calibration=FALSE;  gl_mutex = 0;
}

//////////////////////////////////////////////////////////////////////////////
// EVENT MANAGEMENT
//////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
/* getEventRequestFromTrack() */
/*****************************************************************************/
unsigned char getEventRequestFromTrack(unsigned char* request) {

	 unsigned char trackNumber;

	for (trackNumber=0;trackNumber<4;trackNumber++) {
		if (gl_trackNotification[trackNumber]==TRUE) {
			initRequest(request);
			request[REQ_BOARD_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_TRACK_EVENT]=TRUE;
			request[REQ_EVENT_REQUEST_EVENT_BOARD_TRACK_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_EVENT_TRACK_NUMBER]=trackNumber;
			request[REQ_EVENT_REQUEST_EVENT_VEHICLE_STATUS]=gl_OUTSTATchar[trackNumber]==1 ? ONTRACKValue : OFFTRACKValue;
			gl_mutex=1;gl_trackNotification[trackNumber]=FALSE;gl_mutex=0;
			return (TRUE);
		}
	}
	return(FALSE);	
}

/*****************************************************************************/
/* getEventRequestFromGPIO() */
/*****************************************************************************/
unsigned char getEventRequestFromGPIO(unsigned char* request) {

	 unsigned char GPIONumber;

	for (GPIONumber=0;GPIONumber<3;GPIONumber++) {
		if (gl_GPIONotification[GPIONumber]==TRUE) {
			initRequest(request);
			request[REQ_BOARD_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_GPIO_EVENT]=TRUE;
			request[REQ_EVENT_REQUEST_EVENT_BOARD_GPIO_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_EVENT_GPIO_NUMBER]=GPIONumber;
			request[REQ_EVENT_REQUEST_EVENT_GPIO_LEVEL]=gl_GPIOchar[GPIONumber];
			gl_mutex=1;gl_GPIONotification[GPIONumber]=FALSE;gl_mutex=0;
			return(TRUE);
		}
	}
	return(FALSE);	
}

/*****************************************************************************/
/* getEventRequestFromTIMER() */
/*****************************************************************************/
unsigned char getEventRequestFromTIMER(unsigned char* request) {

	 unsigned char TIMERNumber;

	for (TIMERNumber=0;TIMERNumber<MAXTIMER;TIMERNumber++) {
		if (gl_TIMERNotification[TIMERNumber]==TRUE) {
			initRequest(request);
			request[REQ_BOARD_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_TIMER_EVENT]=TRUE;
			request[REQ_EVENT_REQUEST_EVENT_BOARD_TIMER_NUMBER]=gl_boardNumber;
			request[REQ_EVENT_REQUEST_EVENT_TIMER_NUMBER]=TIMERNumber;
			gl_mutex=1;gl_TIMERNotification[TIMERNumber]=FALSE;gl_mutex=0;
			return(TRUE);
		}
	}
	return(FALSE);	
}


/*****************************************************************************/
/* MAIN */
/*****************************************************************************/
void main()
{
	static unsigned char message[MAXMESSAGESIZE];

	gl_inputCounter=0; // for UART
	sprintf(gl_inputUartString,"");
	gl_parserErrorCode=0;

	// Full init of PIC18F
    init();

	// CALIBRATION
    calibration();

	// START MAIN LOOP
	sprintf(message,RAIL_DRIVER_HEADER);
	prompt(message);

	sprintf(message,"Start board %d",gl_boardNumber);
	prompt(message);

	sprintf(message,"");
	prompt(message);

    while (1){
		while(1) {

			// Get current status on tracks
			if (getEventRequestFromTrack(&gl_request)==TRUE) {
				break;
			}

			// Get current status on GPIO
			if (getEventRequestFromGPIO(&gl_request)==TRUE) {
				break;
			}

			// Get current status on TIMER	
			if (getEventRequestFromTIMER(&gl_request)==TRUE) {
				break;
			}

			// Get Request from CAN Bus
			if (getInputRequestFromCAN(&gl_request)==TRUE) {
				break;		
			}

			// Get Request from RS232 input
			if (getInputRequestFromUSART(gl_inputUartString,&gl_inputCounter)==TRUE) {
				if (strlen(gl_inputUartString)!=0) {

					// Call parser to analyse input request
	       			if (parser(gl_inputUartString,&gl_request)==TRUE) {
						sprintf(gl_inputUartString,"");
						break;
					}
					else { // parsing error
						sprintf(gl_inputUartString,"");
						traceError();
					}		
				}
				else {
					sprintf(message,"");
					prompt(message);
				}
			}
		}

		// Manage request
		if (gl_parserErrorCode!=0) traceError();
		else {
			if (manageRequest(&gl_request,TRUE)==FALSE){
					traceError();
			}
		}
	}
}
