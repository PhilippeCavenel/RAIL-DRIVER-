/*********************************************************************
*
* DRIVER RAIL V 1.2
*
* MAIN.H
*
*********************************************************************
* Processor: PIC18F4585
* Frequency: 32 Mhz
* Compiler: C18
* TYPE                SIZE     RANGE
* char(1,2)            8 bits  -128 127
* signed char          8 bits  -128 127
* unsigned char        8 bits  0 255
* int                 16 bits  -32,768 32,767
* unsigned int        16 bits  0 65,535
* short               16 bits  -32,768 32,767
* unsigned short      16 bits  0 65,535
* short long          24 bits  -8,388,608 8,388,607
* unsigned short long 24 bits  0 16,777,215
* long                32 bits  -2,147,483,648 2,147,483,647
* unsigned long       32 bits  0 4,294,967,295
*********************************************************************/


#include <p18cxxx.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>

#include "ECANPoll.h"

// TRUE FALSE definition as bool not recognized
#define TRUE							1
#define FALSE							0
                         
#define RAIL_DRIVER_HEADER				"RAIL DRIVER V 1.2"

// PROTOCOL
#define MAXINPUTSTRING					200
#define MAXSIZETOKEN					10
#define MAXSIZEIDENT					10
#define MAXTRAMESIZE					80 // Should be multiple of 8
#define MAXTRAMECAN						MAXTRAMESIZE-24
#define MAXMESSAGESIZE					MAXTRAMECAN-2 // We need to add last char and end of string

#define TRAMEPRINTHEADER				0xCC
#define TRAMEPRINTFOOTER				0xDD

#define TRAMEREQUESTHEADER				0xEE
#define TRAMEREQUESTFOOTER				0xFF

#define ENDOFPRINTFTRAME				0x00

// AUTOMATION
#define MAXAUTOMATION					30 // Check size for EEPROM ! if you update this value
#define MAXTIMER						15

#define INITTIMERVALUE					0xFF

//EEPROM
#define SMALL_BUFFER_SIZE				80
#define SUCCESS							1
#define ERROR							0
#define IN_PROGRESS	  					-1
#define MATCH							1
#define DISMATCH	    				2

#define MAGICNUMBER_ADDRESS				0
#define MAGICNUMBERSIZE					8
#define MODE_ADDRESS					(MAGICNUMBERSIZE+1)
#define LASTAUTOMATION_ADDRESS			(MODE_ADDRESS+1)
#define GPIO0DIR_ADDRESS				(LASTAUTOMATION_ADDRESS+1) 	// Don't change this value
#define GPIO1DIR_ADDRESS				(GPIO0DIR_ADDRESS+1) 		// Don't change this order
#define GPIO2DIR_ADDRESS				(GPIO1DIR_ADDRESS+1) 		// Don't change this order
#define GPIO3DIR_ADDRESS				(GPIO2DIR_ADDRESS+1) 		// Don't change this order
#define AUTOMATION_ADDRESS				(GPIO3DIR_ADDRESS+1)		// Should be the last of the list
						

// ERROR CODE
#define UNKNOWN_TOKEN					0x1
#define NUMBER_MISSING					0x2
#define INCOMPLETE_REQUEST				0x3
#define BAD_NUMBER						0x4
#define	MODE_MISSING					0x5
#define BAD_GPIO_NUMBER					0x6
#define BAD_GPIO_DIR					0x7
#define CANT_SET_GPIO_IN_INPUT_MODE		0x8
#define BAD_GPIO_LEVEL					0x9
#define	BAD_LPO_LEVEL					0xA
#define	BAD_LPO_NUMBER					0xB
#define BAD_TRACK_SPEED					0xC
#define BAD_TRACK_DIR					0xD
#define BAD_TRACK_NUMBER				0xE
#define BAD_MODE						0xF
#define WRONG_BOARD_NUMBER				0x10
#define AUTOMATIONSIZELIMIT				0x11
#define MISSING_SPACE					0x12
#define IDENTIFIER_TOO_LONG				0x13
#define AUTOMATIONLREADYEXISTS			0x14
#define BADAUTOMATIONNUMBER				0x15
#define BAD_TIMER_NUMBER				0x16
#define BAD_TIMER_VALUE					0x17
#define BAD_TRACK_STEP					0x18
#define UNKNOWN_ERROR					0xF0

// MSSING ERROR CODE
#define EINVAL							22



// Bits de Configuration 
#pragma config OSC 		= 				IRCIO67 // Oscillateur Interne
#pragma config FCMEN 	= 				OFF
#pragma config IESO 	= 				OFF
#pragma config PWRT 	= 				OFF
#pragma config BOREN 	= 				OFF
#pragma config BORV 	= 				3
#pragma config WDT 		= 				OFF
#pragma config PBADEN 	= 				OFF
#pragma config MCLRE 	= 				OFF
#pragma config LVP 		= 				OFF

// CAN
#define CAN_REQUEST						1
#define CAN_PRINT						2
#define CAN_UNKNOWN						3
#define WAITDELAYTRAMECAN				200
#define SYNCHROSENDDELAY				2

// RS232
#define _XTAL_FREQ    					32000000
#define _BAUD         					115200
#define USARTBUFFERSIZE					127

// VALUES TRACK DIRECTION
#define TRACK_STOP						0	
#define TRACK_FORWARD					1
#define TRACK_BACKWARD					2

// ACCELARATION RATE
#define ACC_RATE						100	

// DELAY FOR DCC SIGNAL
#define DCC_0							48
#define DCC_1							18

// DCC PREAMBLE SIZE
#define PREAMBLE_SIZE					21
#define FRAME_SIZE						(PREAMBLE_SIZE+(3*9)+2)
#define MAX_STEP_COUNTER				0xf
#define INITWAITDCCCOUNTER				4

// CURRENT DETECTION 
#define HYSTERERISHIGH					2
#define HYSTERERISLOW					1
#define SAMPLEFORAVERAGE				30
#define SAMPLEFORCALIBRATION			5
#define TIMECALIBRATION 				0xFFF

// GPIO DETECTION
#define GPIOTHRESHOLD					100



// CIRCUIT 0 ////////////////////////////
#define S1T0							PORTAbits.RA4
#define S2T0    						PORTAbits.RA7
#define OUTSTAT0						PORTAbits.RA5
#define CURT0       					0x0 + 0x1 // ADCON0 ON AN0 + ADON

// CIRCUIT 1 ////////////////////////////
#define S1T1							PORTAbits.RA6
#define S2T1    						PORTCbits.RC0
#define OUTSTAT1						PORTEbits.RE0
#define CURT1       					0x4 + 0x1 // ADCON0 ON AN1 + ADON

// CIRCUIT 2 ////////////////////////////
#define S1T2							PORTCbits.RC1
#define S2T2    						PORTCbits.RC2
#define OUTSTAT2						PORTEbits.RE1
#define CURT2       					0x8 + 0x1 // ADCON0 ON AN2 + ADON

// CIRCUIT 3 ////////////////////////////
#define S1T3							PORTCbits.RC3
#define S2T3    						PORTDbits.RD0
#define OUTSTAT3						PORTEbits.RE2
#define CURT3       					0x4 + 0x8 + 0x1 // ADCON0 ON AN3 + ADON

// OUTPUT ////////////////////////////

#define OUT0        					PORTDbits.RD6
#define OUT1        					PORTDbits.RD7
#define OUT2        					PORTBbits.RB0
#define OUT3        					PORTBbits.RB1
#define OUT4        					PORTBbits.RB4
#define OUT5        					PORTBbits.RB5

// SWITCH IN ////////////////////////////

#define IN0								PORTCbits.RC5
#define IN1								PORTCbits.RC6
#define IN2								PORTCbits.RC7
#define IN3								PORTDbits.RD4
#define IN4								PORTDbits.RD5

// GPIO IN ///////////////////////////

#define GPIO0							PORTDbits.RD1
#define GPIO1							PORTDbits.RD2
#define GPIO2							PORTDbits.RD3
#define GPIO3							PORTCbits.RC4

///////////////////////////////////////////////
// Token
///////////////////////////////////////////////

#define PROG							"PROG"
#define COM								"COM"
#define DCC								"DCC"
#define STOP							"STOP"
#define RUNALL 							"RUNALL"
#define ANA								"ANA"
#define LPO								"LPO"
#define GPIO							"GPIO"
#define TRACK							"TRACK"
#define VAL								"VAL"
#define IN								"IN"
#define ACT								"ACT"
#define STA								"STA"
#define OUT								"OUT"
#define ONTRACK							"ONTRACK"
#define OFFTRACK						"OFFTRACK"
#define DEL								"DEL"
#define DIR								"DIR"
#define FORW							"FORW"
#define BACK							"BACK"
#define GSTAT							"GSTAT"
#define LSTAT							"LSTAT"
#define TSTAT							"TSTAT"
#define BSTAT							"BSTAT"
#define AUTLIST							"AUTLIST"
#define AUT								"AUT"
#define BOARD							"BOARD"
#define ERR								"ERR"
#define AUTFULL							"AUTFULL"
#define NOAUT							"NOAUT"
#define TIMEOUT							"TIMEOUT"
#define NODCC							"NODCC"
#define NOANA							"NOANA"
#define GPIOIN							"GPIOIN"
#define RUN								"RUN"
#define RESET							"RESET"
#define TIMER							"TIMER"
#define STEP							"STEP"
#define SPEED							"SPEED"

///////////////////////////////////////////////
//Token Value
///////////////////////////////////////////////

#define PROGValue 						0x01
#define COMValue 						0x02
#define DCCValue 						0x03
#define STOPValue 						0x04
#define RUNALLValue 					0x05
#define ANAValue 						0x06
#define LPOValue 						0x07
#define GPIOValue 						0x08
#define TRACKValue 						0x09
#define VALValue 						0x0A
#define INValue 						0x0B
#define ACTValue 						0x0C
#define STAValue 						0x0D
#define OUTValue 						0x0E
#define ONTRACKValue 					0x0F
#define OFFTRACKValue 					0x10
#define DELValue 						0x11
#define DIRValue 						0x12
#define FORWValue 						0x13
#define BACKValue 						0x14
#define GSTATValue 						0x15
#define TSTATValue						0x16
#define BSTATValue 						0x17
#define LSTATValue 						0x18
#define AUTLISTValue 					0x19
#define AUTValue 						0x1A
#define BOARDValue 						0x1B
#define ERRValue 						0x1C
#define AUTFULLValue 					0x1D
#define NOAUTValue 						0x1E
#define TIMEOUTValue 					0x1F
#define NODCCValue 						0x20
#define NOANAValue						0x21
#define GPIOINValue 					0x22
#define RUNValue 						0x23
#define RESETValue 						0x24
#define TIMERValue						0x25
#define STEPValue						0x26
#define SPEEDValue						0x27


///////////////////////
// STRUCTURE REQUEST
// ////////////////////

// DONT CHANGE THE FOLLOWING VALUES OR ORDERS
/////////////////////////////////////////////


#define REQ_MODE									0
#define REQ_BOARD_NUMBER 							1
#define REQ_GLOBAL_COMMAND 							2

#define REQ_COMMAND_REQUEST_SET_GPIO 				3
#define REQ_COMMAND_REQUEST_GPIO_NUMBER 			4
#define REQ_COMMAND_REQUEST_GPIO_LEVEL 				5

#define REQ_COMMAND_REQUEST_SET_TIMER 				6
#define REQ_COMMAND_REQUEST_TIMER_NUMBER 			7
#define REQ_COMMAND_REQUEST_TIMER_DELAY				8

#define REQ_COMMAND_REQUEST_SET_LPO 				9
#define REQ_COMMAND_REQUEST_LPO_NUMBER 				10
#define REQ_COMMAND_REQUEST_LPO_LEVEL 				11

#define REQ_COMMAND_REQUEST_SET_TRACK 				12
#define REQ_COMMAND_REQUEST_TRACK_NUMBER 			13
#define REQ_COMMAND_REQUEST_TRACK_SPEED 			14
#define REQ_COMMAND_REQUEST_TRACK_DIR 				15
#define REQ_COMMAND_REQUEST_TRACK_STEP				16

#define REQ_COMMAND_REQUEST_SET_DCC					17
#define REQ_COMMAND_REQUEST_DCC_ADDRESS 			18
#define REQ_COMMAND_REQUEST_DCC_COMMAND				19

#define REQ_COMMAND_REQUEST_GET_GPIO_STATUS			20 
#define REQ_COMMAND_REQUEST_GET_LPO_STATUS 			21
#define REQ_COMMAND_REQUEST_GET_TRACK_STATUS 		22
#define REQ_COMMAND_REQUEST_GET_BOARD_STATUS 		23
#define REQ_COMMAND_REQUEST_GET_AUTOMATION_LIST 	24

#define REQ_COMMAND_REQUEST_GET_TIMER_STATUS		25	

#define REQ_PROGRAM_REQUEST_SET_BOARD_MODE 			26	
#define REQ_PROGRAM_REQUEST_BOARD_MODE 				27

#define REQ_PROGRAM_REQUEST_SET_GPIO 				28
#define REQ_PROGRAM_REQUEST_SET_GPIO_NUMBER 		29
#define REQ_PROGRAM_REQUEST_SET_GPIO_DIR 			30


#define REQ_PROGRAM_REQUEST_SET_TIMER 				31
#define REQ_PROGRAM_REQUEST_SET_TIMER_NUMBER 		32
#define REQ_PROGRAM_REQUEST_SET_GPIO_VALUE 			33


#define REQ_PROGRAM_REQUEST_SET_AUTOMATION 			34

#define REQ_PROGRAM_REQUEST_GPIO_EVENT 				35

#define START_HERE_TO_COPY_FOR_AUTOMATION			REQ_PROGRAM_REQUEST_GPIO_EVENT

#define REQ_PROGRAM_REQUEST_EVENT_BOARD_GPIO_NUMBER 36
#define REQ_PROGRAM_REQUEST_EVENT_GPIO_NUMBER 		37
#define REQ_PROGRAM_REQUEST_EVENT_GPIO_LEVEL 		38

#define REQ_PROGRAM_REQUEST_TIMER_EVENT 			39	
#define REQ_PROGRAM_REQUEST_EVENT_BOARD_TIMER_NUMBER 40
#define REQ_PROGRAM_REQUEST_EVENT_TIMER_NUMBER 		41			

#define REQ_PROGRAM_REQUEST_TRACK_EVENT 			42
#define REQ_PROGRAM_REQUEST_EVENT_BOARD_TRACK_NUMBER 43
#define REQ_PROGRAM_REQUEST_EVENT_TRACK_NUMBER 		44
#define REQ_PROGRAM_REQUEST_EVENT_VEHICLE_STATUS 	45

#define REQ_PROGRAM_REQUEST_GPIO_SETTING 			46
#define REQ_PROGRAM_REQUEST_ACTION_GPIO_SET_NUMBER 	47
#define REQ_PROGRAM_REQUEST_ACTION_GPIO_SET_LEVEL 	48

#define REQ_PROGRAM_REQUEST_TIMER_SETTING 			49
#define REQ_PROGRAM_REQUEST_ACTION_TIMER_SET_NUMBER 50	
#define REQ_PROGRAM_REQUEST_ACTION_TIMER_SET_DELAY	51

#define REQ_PROGRAM_REQUEST_LPO_SETTING 			52
#define REQ_PROGAM_REQUEST_ACTION_LPO_SET_NUMBER	53
#define REQ_PROGRAM_REQUEST_ACTION_LPO_SET_LEVEL 	54

#define REQ_PROGRAM_REQUEST_TRACK_SETTING 			55
#define REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_NUMBER 56
#define REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_SPEED 	57
#define REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_DIR 	58
#define REQ_PROGRAM_REQUEST_ACTION_TRACK_SET_STEP	59

#define REQ_PROGRAM_REQUEST_DCC_SETTING 			60
#define REQ_PROGRAM_REQUEST_ACTION_DCC_ADDRESS_SETTING 	61
#define REQ_PROGRAM_REQUEST_ACTION_DCC_COMMAND_SETTING 	62

#define REQ_PROGRAM_REQUEST_IDENT					63	

#define REQ_PROGRAM_REQUEST_DEL_AUTOMATION 			(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT)
#define REQ_PROGRAM_REQUEST_AUTOMATION_NUMBER 		(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+1)

#define REQ_EVENT_REQUEST_TRACK_EVENT 				(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+2)
#define REQ_EVENT_REQUEST_EVENT_BOARD_TRACK_NUMBER 	(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+3)
#define REQ_EVENT_REQUEST_EVENT_TRACK_NUMBER 		(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+4)
#define REQ_EVENT_REQUEST_EVENT_VEHICLE_STATUS 		(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+5)

#define REQ_EVENT_REQUEST_GPIO_EVENT 				(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+6)
#define REQ_EVENT_REQUEST_EVENT_BOARD_GPIO_NUMBER 	(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+7)
#define REQ_EVENT_REQUEST_EVENT_GPIO_NUMBER 		(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+8)
#define REQ_EVENT_REQUEST_EVENT_GPIO_LEVEL 			(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+9)	

#define REQ_EVENT_REQUEST_TIMER_EVENT 				(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+10)
#define REQ_EVENT_REQUEST_EVENT_BOARD_TIMER_NUMBER 	(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+11)
#define REQ_EVENT_REQUEST_EVENT_TIMER_NUMBER 		(REQ_PROGRAM_REQUEST_IDENT+MAXSIZEIDENT+12)

#define REQUESTSIZE									(REQ_EVENT_REQUEST_EVENT_TIMER_NUMBER+1)

///////////////////////
// STRUCTURE AUTOMATION
// ////////////////////

// DONT CHANGE THE FOLLOWING VALUES OR ORDERS
/////////////////////////////////////////////

#define AUTOMATION_EVENT_GPIO_EVENT					0
#define AUTOMATION_EVENT_EVENT_BOARD_GPIO_NUMBER	1
#define AUTOMATION_EVENT_EVENT_GPIO_NUMBER			2
#define AUTOMATION_EVENT_EVENT_GPIO_LEVEL			3

#define AUTOMATION_EVENT_TIMER_EVENT				4	
#define AUTOMATION_EVENT_EVENT_BOARD_TIMER_NUMBER	5
#define AUTOMATION_EVENT_EVENT_TIMER_NUMBER			6			

#define AUTOMATION_EVENT_TRACK_EVENT				7
#define AUTOMATION_EVENT_EVENT_BOARD_TRACK_NUMBER	8
#define AUTOMATION_EVENT_EVENT_TRACK_NUMBER			9
#define AUTOMATION_EVENT_EVENT_VEHICLE_STATUS		10

#define AUTOMATION_COMMAND_SET_GPIO					11
#define AUTOMATION_COMMAND_GPIO_NUMBER				12
#define AUTOMATION_COMMAND_GPIO_LEVEL				13

#define AUTOMATION_COMMAND_SET_TIMER				14	
#define AUTOMATION_COMMAND_TIMER_NUMBER				15
#define AUTOMATION_COMMAND_TIMER_DELAY				16

#define AUTOMATION_COMMAND_SET_LPO					17
#define AUTOMATION_COMMAND_LPO_NUMBER				18
#define AUTOMATION_COMMAND_LPO_LEVEL				19

#define AUTOMATION_COMMAND_SET_TRACK				20
#define AUTOMATION_COMMAND_TRACK_NUMBER				21
#define AUTOMATION_COMMAND_TRACK_SPEED				22
#define AUTOMATION_COMMAND_TRACK_DIR				23
#define AUTOMATION_COMMAND_TRACK_STEP				24

#define AUTOMATION_COMMAND_SET_DCC					25
#define AUTOMATION_COMMAND_DCC_ADDRESS				26
#define AUTOMATION_COMMAND_DCC_COMMAND				27
#define IDENT										28

#define AUTOMATIONSIZE							   (IDENT+MAXSIZEIDENT+1)


///////////////////////////////////////////////
// global variables
///////////////////////////////////////////////

unsigned char  				gl_S1T0char = 0;
unsigned char  				gl_S2T0char = 0;

unsigned char  				gl_S1T1char = 0;
unsigned char  				gl_S2T1char = 0;

unsigned char  				gl_S1T2char = 0;
unsigned char  				gl_S2T2char = 0;

unsigned char  				gl_S1T3char = 0;
unsigned char  				gl_S2T3char = 0;

unsigned char  				gl_OUTchar[6];


// BOARD NUMBER FROM SWITCH SETTING
unsigned char				gl_boardNumber;

// MASTER 
unsigned char				gl_master;

// SPEED MANAGEMENT IN ANALOG MODE
unsigned char				gl_speedCounter;
 
   // SPEED CIRCUIT 
int							gl_setPoint[4];	  // SPEED AND DIRECTION REQUESTEDint							
int							gl_setStep[4];	  // STEP TO CHANGE SPEED AND DIRECTION REQUESTED
int							gl_curSpeed[4];	  // CUR SPEED AND DIRECTION

// low level value
unsigned char 				gl_speed[4];  
unsigned char 				gl_direction[4];  // DIRECTION CIRCUIT 

// SIGNAL MANAGEMENT IN DIGITAL MODE
unsigned char 				gl_signalState;
unsigned char 				gl_dcc[FRAME_SIZE]; 
char 						gl_dcc_ready;

// MODE
unsigned char 				gl_mode;	

// MUTEX
unsigned char 				gl_mutex;

unsigned char				gl_trackNumber;

// USART
#pragma udata USART
static unsigned char 		gl_receivedUSARTData[USARTBUFFERSIZE];
#pragma udata

unsigned char 				gl_receivedUSARTPointer;
unsigned char 				gl_getDataUSARTPointer;
char						gl_inputCounter;

// PROTOCOL
#pragma udata PROTOCOL
unsigned char 				gl_inputUartString[MAXINPUTSTRING];
unsigned char 				gl_request[REQUESTSIZE];
unsigned char		 		gl_automation[MAXAUTOMATION][AUTOMATIONSIZE];
unsigned char 				gl_dataStructure[MAXTRAMESIZE];
unsigned char 				gl_outputBuffer[MAXTRAMESIZE];
unsigned char 				gl_inputBuffer[MAXTRAMESIZE];
unsigned char 				gl_tmpBuffer[MAXTRAMESIZE];
#pragma udata

unsigned short 				gl_lastAutomation;
unsigned char				gl_outputBufferCounter;
unsigned char				gl_InputBufferPointer;
unsigned char 				gl_getDataCANPointer;
unsigned char 				gl_canMode;
char						gl_requestTrameStart;
char						gl_printTrameStart;

// error info
unsigned char 				gl_parserErrorCode;

// CUR TRACK STATUS
unsigned int				gl_average[4];
unsigned int 				gl_noVehicule[4];
unsigned char  				gl_calibration;
unsigned char  				gl_OUTSTATchar[4];
unsigned char  				gl_trackNotification[4];

// CUR GPIO STATUS
unsigned char				gl_GPIONotification[4];
unsigned char				gl_GPIOchar[4];
unsigned int				gl_GPIOstabilized[4];

// CUR TIMER 

unsigned char				gl_TIMERValue[MAXTIMER];
unsigned char				gl_TIMERNotification[MAXTIMER];
unsigned char				gl_timerNumber;
unsigned short				gl_timer;

// RUN OR STOP ALL
unsigned char 				gl_stopAll;

// SYNCHRO SEND
unsigned short				gl_synchroSend;

///////////////////////////////////////////////
// function declaration
///////////////////////////////////////////////

// EEPROM READ / WRITE FUNCTION
unsigned char 	ReadEEPROM(unsigned int adr, unsigned char *data);
void 			ResetEEPROM();
void 			ReadEEPROMConfig(void);
unsigned char 	WriteCompletedEEPROM(void);
unsigned char 	WriteRdyEEPROM(void);
unsigned char 	WriteEEPROM(unsigned short adr, unsigned char data);

// PARSER AND REQUEST MANAGEMENT
unsigned char 	isAdigit(unsigned char car);
unsigned char 	isAhexaDigit(unsigned char car);
unsigned char 	toUpperCase(unsigned char car);
unsigned short 	strtol_with_atoi(const char* nptr, short base);
void 			traceError();
unsigned char 	getToken(unsigned char* inputString, unsigned char* inputToken, unsigned char* stringPointer);
unsigned char 	getValue(unsigned char* inputString, unsigned char* Value, unsigned char* stringPointer);
unsigned char 	parser(unsigned char* inputString, unsigned char* request);
void 			uncompressData(unsigned char* data);
unsigned char 	compressData(unsigned char* data);
void 			setRequest(unsigned char* request, unsigned char* data,unsigned char init);
unsigned char 	getDataFromRequest(unsigned char* request, unsigned char* data);
void 			initRequest(unsigned char* request);
void 			assignAutomation(char *request,unsigned char automationCounter);
unsigned char 	manageRequest (unsigned char* request,unsigned char sendPrompt);

// UART
void 			initUSART();
void 			sendUSART(unsigned char data);
unsigned char 	getInputRequestFromUSART(unsigned char *inputString,char *inputCounter);
void 			prompt(unsigned char* message);

// CAN
void 			flushOut();
void			 CANsendDelay();
int 			_user_putc(char c);
void 			sendRequestToCAN(unsigned char* request);
unsigned char	getInputRequestFromCAN(unsigned char* request);

// INTERRUPT AND SIGNAL MANAGEMENT
void 			setDcc(unsigned char address, unsigned char command);
void 			setPort();
void 			interrupt_at_high_vector(void);
void  			interrupt_at_low_vector(void);
void 			high_isr(void);
void 			low_interrupt();
void 			low_isr(void);

// CODE INITIALISATION
void 			initSignal();
void 			PIC18FMainSettings();
void 			init();
void 			calibration();

// EVENT MANAGEMENT
unsigned char 	getEventRequestFromTrack(unsigned char* request);
unsigned char 	getEventRequestFromGPIO(unsigned char* request);
unsigned char 	getEventRequestFromTIMER(unsigned char* request);







